@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0Setup.vbs" (
  echo Setup.vbs is missing. Extract the entire ZIP before running setup.
  pause
  exit /b 1
)
if not exist "%SystemRoot%\System32\wscript.exe" (
  echo Windows Script Host is unavailable. Use the manual files inside payload.
  pause
  exit /b 1
)
start "Feeling Dizzy Yet Setup" /wait "%SystemRoot%\System32\wscript.exe" //nologo "%~dp0Setup.vbs"
exit /b %errorlevel%
