# Feeling Dizzy Yet

Edit with intent.

## Identity
Three tilted nested orbits, interrupted by a deliberate cut: motion, timeline control, and a recognisable silhouette. The production mark uses clean vector geometry and outlined wordmarks. No generic robot, brain, sparkle, or circuit imagery.

## Palette
Acid lime #CAFA6B; ink #15191F; warm white #F4F1E8; slate #323B49.
Use lime on ink. Use ink mark on light backgrounds. Preserve clear space of at least one outer stroke. Use the symbol alone below 160px wordmark width. Avoid shadows, glow, stretching, and extra rotations. Do not add unofficial Adobe endorsement marks.

## Files
SVG vector masters, transparent PNG exports, outlined wordmark variants, Mac ICNS icon, panel-sized mark, and brand board. Fonts in the wordmark are outlined. Application controls use native system typography for legibility.

## Process and limitations
Built-in image generation explored the nested broken-orbit mark. Production vector geometry and typography were then implemented for crisp interface and installer assets. This is an original design direction, not a trademark clearance or a promise that no similar marks exist.

Generation direction: flat acid-lime nested rounded-square broken loops, tilted, transparent background, no text, no texture, no generic AI imagery. Refinement direction: clean contours, uniform fills and clear negative space.
