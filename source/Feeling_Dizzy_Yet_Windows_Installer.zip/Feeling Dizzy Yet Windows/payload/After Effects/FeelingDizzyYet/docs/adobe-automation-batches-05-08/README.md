# Adobe Automation Starter — batches 05–08
Version 0.3.0 • Scripts 21–40 • After Effects only

Twenty standalone ExtendScript source tools. No bridge, AI account, API key or network access. Earlier batches are separate. These do not run in Premiere and do not perform automatic multicam editing. Development preview, not a certified commercial release.

## Run
Extract ZIP. Open a saved copy of a project in After Effects. File > Scripts > Run Script File > choose a .jsx. No permanent installation needed. Most tools require an active composition. Scripts never save projects or start renders. Scripts group changes for Undo; errors can still leave partial changes. Test on disposable projects first.

## Batches
05 (21–25): layout tools. Selected layers must be unlocked, unparented and 2D. Positions must be static with combined dimensions. Alignments use anchor points, not visible bounding boxes.
06 (26–30): typography, keyframes, animation, markers. Animation tools refuse to overwrite existing animation on the property they change.
07 (31–35): burned-in caption layers and title compositions. Captions are NOT Premiere caption tracks or sidecar subtitle exports. Text needs visual review.
08 (36–40): media layout and copyable inspection reports. Reports are heuristic and do not certify delivery quality.

## Script details
- 21 Center Selected Layers.jsx
- 22 Fit Selected Visual Layers.jsx
- 23 Grid Selected Layers.jsx
- 24 Align Selected Layers.jsx
- 25 Distribute Selected Layers.jsx
- 26 Scale Selected Text.jsx
- 27 Ease Selected Keyframes.jsx
- 28 Slide In Selected Layers.jsx
- 29 Slow Zoom Selected Layers.jsx
- 30 Layer Name Markers.jsx
- 31 Captions From TSV.jsx
- 32 Captions From SRT.jsx
- 33 Create End Card.jsx
- 34 Create Countdown.jsx
- 35 Chapter Cards From TSV.jsx
- 36 Create Media Contact Sheet.jsx
- 37 Missing Footage Report.jsx
- 38 Text Inventory.jsx
- 39 Expression Error Report.jsx
- 40 Project Composition Catalog.jsx

## Important behavior
21 centers anchor points; artwork may remain visually off-center.
22 fit/fill resets anchors, positions and scales of supported source layers. Square pixels required. Fit adds empty space; fill crops. No masks/effects/rotation-aware fitting.
23 grid changes positions only; it does not resize layers or prevent overlap.
24 align accepts x/y and a coordinate. 25 distributes anchor points between existing extremes.
26 adjusts font size; mixed formatting may normalize.
27 applies zero-speed temporal ease to selected numeric keys; it changes easing. Excludes text/color/custom properties and expression-driven properties. Does not change spatial paths.
28 adds linear slide-in keys from an offset to the current position at layer start.
29 adds linear scale keys over visible layer duration. It does not guarantee edge coverage.
30 adds composition markers from selected layer names/in-points; rejects same-frame collisions before writes.
31 uses UTF-8 TSV with mandatory header and start_seconds, end_seconds, text columns. No embedded tabs/newlines. Entire cue list validated before layer creation.
32 accepts numbered plain SRT with HH:MM:SS,mmm or HH:MM:SS.mmm. No cue-position settings; markup appears literally. Overlapping captions are allowed and can overlap visually. All cue timings checked before layer creation.
33 makes a 1920x1080 closing card; 34 makes a 1–300-second countdown with one number layer per second; 35 makes chapter cards from TSV. Long text can overflow.
36 selects visual items in Project panel, not layers. Fits them in a five-second contact-sheet comp. Sources play normally; this is not a set of extracted stills. Very dense layouts can have unreadable labels.
37 lists missing-footage flags. Does not relink files or inspect proxies.
38 reports current evaluated Source Text, not every text keyframe or style run.
39 reads current expression error strings, not every frame; nested comps excluded.
40 lists all composition items and their dimensions, fps, durations, and layer counts.

## Testing status
Node syntax checks and mock-host behavioral tests are included in verify.js (run node verify.js). These do not prove Adobe compatibility. No Adobe host was available: runtime behavior, rendering, fonts, localization, and visual layout remain unverified. Your friend must test before production use or sale.

## Friend smoke tests
Create a 10-second, square-pixel comp with three unparented 2D visual layers and static transforms. Exercise 21–25, undoing between tests. Try parented/3D/locked layers and verify rejection. Check fit/fill, anchor changes, and grid overlap.
Create plain text layers for 26. For 27 select numeric keyframes; verify easing in Graph Editor. Test 28–29 with plain layers and with pre-existing animation (must reject). For 30 use unique in-points, then repeat (must reject marker collisions).
Run 31 and 32 in a >=5-second comp using examples; compare start/end times, text and line wrapping. Invalid or out-of-range cues should create no layers. Compare caption render with preview.
Run 33–35 and inspect text placement. Run 36 with 3–6 visual project items and inspect first and later frames. Compare 37–40 against a known project, including intentional missing media or expression errors.
Report: AE version, OS, filename, input, expected/actual result, exact error/line number, undo result, and visual issues.

## AI use
Claude/OpenAI can prepare input data or modify these scripts. Chat alone cannot execute them in Adobe. A future local adapter could expose the scripts as named tools.
