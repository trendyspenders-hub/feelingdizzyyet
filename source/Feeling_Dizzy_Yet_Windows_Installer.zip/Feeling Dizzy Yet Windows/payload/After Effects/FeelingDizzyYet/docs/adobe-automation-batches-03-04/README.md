# Adobe Automation Starter — batches 03–04
Version 0.2.0. Ten NEW After Effects scripts (11–20). Earlier scripts are not included. Standalone source preview; no bridge, account, API key, or network dependency. Not Premiere scripts. Not a live AI integration.

## Run
Extract ZIP. Save a copy of your project. In After Effects use File > Scripts > Run Script File and choose a .jsx file. Most tools require an active composition. Layer tools require selected, unlocked layers. Start with a disposable project. Cancel stops further processing; host errors can leave partial changes. Each script groups changes for Edit > Undo; undo behavior still needs host testing. Scripts never save projects or start rendering.

## Batch 03 — layer workflow
11 Number Selected Layers: rename selected layers in timeline index order using prefix and padded numbers. Intentional existing names are replaced; undo to restore.
12 Label Selected Layers: apply label index 0–16. Colors depend on your AE preferences.
13 Fade Selected Layers: add linear opacity fades while preserving each layer's original opacity as the middle level. Rejects existing opacity animation/expressions and layers too short for two fades. Prevalidates all selected layers.
14 Stagger Selected Layers: shift later selected layers by increasing whole-frame offsets. Moves entire layer timing, not just in-points. Rejects resulting out-points beyond comp end. Does not detect time-based expressions or relationships to unselected layers.
15 Work Area From Selection: set work area to the visible span of selected layers, clamped to comp bounds. Does not trim the composition or layers.

## Batch 04 — text and review
16 Replace Selected Text: literal, case-sensitive find/replace on selected text layers. Non-text layers ignored. Animated/expression-driven Source Text rejected. Rewriting Source Text may normalize mixed formatting: inspect typography.
17 Update Text From TSV: exact layer-name-to-text mapping in active comp. Requires unique TSV names and exactly one matching unlocked text layer per name. All input rows validated before writes. Use examples/text_updates.tsv after creating layers named Guest Name and Guest Role. UTF-8 tabs; mandatory header skipped; no tabs/newlines inside cells. Empty replacement text is allowed. Mixed text formatting may normalize.
18 Add Review Watermark: full-duration text layer with configurable opacity. Rendered normally, not a guide. Long text may overflow. Run again creates another layer.
19 Add Safe Area Overlay: four guide-layer lines at a configurable percentage inset. No actual cropping or delivery certification. Inspect render settings; guide layers can be included if specifically enabled. Re-running creates another overlay.
20 Composition Preflight Report: read-only dialog with basic flags for current comp. Disabled layers may be intentional. Does not recurse or analyze actual media, audio loudness, fonts, exports, or visual quality.

## Status
JavaScript parse checks and selected mock-based behavioral checks are included in verify.js (run: node verify.js). These are not Adobe execution tests or proof of legacy ExtendScript compatibility. Actual AE version/OS compatibility and all visual outputs remain UNVERIFIED. Do not advertise as tested or sell as a finished release yet.

## Suggested friend test
Use a 10-second comp with three unlocked text layers, no keyframes, in/out points 0–5 seconds. Run 11 and undo; run 12 and undo. Run 13 with 0.3 seconds and inspect opacity keys and undo. Add an existing opacity key and confirm 13 rejects without modifying other layers. Run 14 at five frames and inspect start times. Run 15 and inspect work area. Name two text layers Guest Name and Guest Role; run 17 with example TSV and verify text. Repeat with a missing/duplicate layer name and confirm no writes. Test 16 with literal punctuation. Inspect watermark and overlay in comp viewer and a test render. Run 20 and compare reported flags. Try cancel, invalid numbers, locked layers, empty selection, and no active comp.

## Report template
AE version / OS:
Script filename:
Steps and input:
Expected / actual result:
Exact error and line number:
Undo result:
Visual notes:

## Next integration
These actions can later be exposed as callable AI tools through a separate local adapter. No connector is included. Premiere development remains dependent on the target Premiere version and OS.
