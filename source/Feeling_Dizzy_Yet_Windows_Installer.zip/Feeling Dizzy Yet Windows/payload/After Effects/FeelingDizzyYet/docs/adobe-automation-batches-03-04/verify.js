const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const dir=path.join(__dirname,'scripts');
for(const f of fs.readdirSync(dir))new vm.Script(fs.readFileSync(path.join(dir,f),'utf8'),{filename:f});
function layer(index,options={}){const op={numKeys:0,expressionEnabled:false,value:75,keys:[],setValueAtTime(t,v){this.keys.push([t,v])}};const txt={numKeys:0,expressionEnabled:false,value:{text:'Original'},setValue(v){this.value=v;this.writes=(this.writes||0)+1}};return Object.assign({index,name:'Layer '+index,locked:false,inPoint:0,outPoint:5,startTime:0,op,txt,property(key){if(key==='ADBE Transform Group')return {property(){return op}};if(key==='ADBE Text Properties')return {property(){return txt}}}},options);}
function run(file,layers,answers=[],tsv=''){function CompItem(){}const c=new CompItem();Object.assign(c,{selectedLayers:layers,duration:10,frameRate:30,numLayers:layers.length,layer(i){return layers[i-1]}});let b=0,e=0;const alerts=[];const ctx={CompItem,app:{project:{activeItem:c},beginUndoGroup(){b++},endUndoGroup(){e++}},prompt(){return answers.length?answers.shift():null},alert(v){alerts.push(v)},File:{openDialog(){return {open(){return true},read(){return tsv},close(){}}}}};vm.runInNewContext(fs.readFileSync(path.join(dir,file+'.jsx'),'utf8'),ctx);assert.equal(b,e);return {c,alerts};}
let a=[layer(2),layer(1)];run('11_Number_Selected_Layers',a,['Guest','1']);assert.equal(a[0].name,'Guest 001');assert.equal(a[1].name,'Guest 002');
a=[layer(1),layer(2,{locked:true})];run('11_Number_Selected_Layers',a,['Guest','1']);assert.equal(a[0].name,'Layer 1');
a=[layer(1),layer(2)];a[1].op.numKeys=1;run('13_Fade_Selected_Layers',a,['0.3']);assert.equal(a[0].op.keys.length,0);
a=[layer(1)];run('13_Fade_Selected_Layers',a,['0.3']);assert.equal(a[0].op.keys.length,4);assert.equal(a[0].op.keys[1][1],75);
a=[layer(1),layer(2,{outPoint:10})];run('14_Stagger_Selected_Layers',a,['5']);assert.equal(a[0].startTime,0);assert.equal(a[1].startTime,0);
a=[layer(1),layer(2)];run('14_Stagger_Selected_Layers',a,['6']);assert.equal(a[1].startTime,0.2);
a=[layer(1,{name:'Guest Name'}),layer(2,{name:'Guest Role'})];run('17_Update_Text_From_TSV',a,[],'layer_name\ttext\nGuest Name\tAlex\nMissing\tOops');assert.equal(a[0].txt.writes,undefined);
a=[layer(1,{name:'Guest Name'}),layer(2,{name:'Guest Role'})];run('17_Update_Text_From_TSV',a,[],'layer_name\ttext\nGuest Name\tAlex\nGuest Role\tHost');assert.equal(a[0].txt.value.text,'Alex');assert.equal(a[1].txt.value.text,'Host');
a=[layer(1)];run('12_Label_Selected_Layers',a,[null]);assert.equal(a[0].label,undefined);
console.log('PASS: 10 syntax checks, 9 mock scenarios including validation-before-write, animation protection, timing bounds, TSV updates and cancellation. Adobe tests pending.');
