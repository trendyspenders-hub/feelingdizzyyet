# Adobe host test plan
Record AE version, OS, exact script, inputs, errors/line number, undo behavior, and screenshots where useful.

- 41–44: use duplicate test footage/comps; verify only selected items change, disk paths stay identical, Undo restores names/folders/labels. Reject folder selection in 41.
- 45–47: use two short visual clips and three stills. Inspect source-sized comps, sequence order, audio, total duration, dissolve overlaps, and zero-overlap mode. Verify video rejected by still slideshow.
- 48–50: inspect duplicate names/shared nested sources; run episode folders twice and check reuse; verify text layers skipped by rename-from-source.
- 51–54: select exactly expected visual project items; verify cells, fit versus fill, ALL source audio muted, duration, source order. Short sources should end naturally. These tools do not sync clips.
- 55–57: use layers with and without audio; compare level changes and fade keys. Existing keyframes and locked selected layers should prevent writes. Audition for clipping and fades.
- 58–60: inspect marker times/durations and preservation of comments. Test invalid row, collision, and out-of-range end; TSV validation should add no markers on failure.
- 61–65: inspect long text, portrait event cards, credit scroll at first/last frames, progress bar left edge and fill at end. Render sample frames.
- 66–70: test elapsed timer including nonzero display start; list limits; timed titles TSV; transparent logo and source duration; repeat seams and retained audio.
- 71–74: verify only intended project/layer state changes; test cancel for folder deletion. No disk files should change.
- 75: run launcher, cancel, select one tool, verify correct script opens and errors display normally.
- Across all: test no project, no active comp, empty/wrong selections, Cancel, invalid numbers, and non-English application UI. Use a project copy.
