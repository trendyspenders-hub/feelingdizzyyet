# Adobe Automation Starter — batches 09–15
Version 0.4.0 • 35 NEW scripts, numbered 41–75 • After Effects only

Standalone editable JSX source. No AI account, API key, network, or bridge. Earlier scripts are separate. These are not Premiere scripts or automatic multicam editors. Four layout tools are explicit layout variants, not separate camera-analysis engines.

## Run
Extract ZIP. Open a saved copy of a project. In After Effects choose File > Scripts > Run Script File, select one JSX, or run 75_Batch_Script_Launcher.jsx to choose from this package. Project-panel selections and composition layer selections are different: read the relevant tool's prompt. No permanent installation needed. No script saves your project or starts rendering. Changes are grouped for Undo, but failed host operations can leave partial changes. Use disposable test projects.

## Batches and behavior
09 (41–45): project organization, prefixing, literal name replacement, labels, source-sized composition creation. Renaming changes project item display names, NOT disk filenames. Type sorting moves only selected items. Source-sized compositions retain source audio. Still duration defaults to five seconds.
10 (46–50): sequential assembly, still slideshow, version duplicates, episode folder structure, and restoring source-backed layer names. Assembly order is Project selection order, not filename order. Review source audio and mixed frame rates. Slideshow is still images only; fit scaling does not fill the frame. Duplicated comps share nested sources. Folder tools affect the AE project only.
11 (51–55): horizontal two-person, vertical stacked interview, four-person grid, presenter-and-slides, and muting selected layers. Layout tools create per-cell nested comps to crop correctly when using fill. Select exactly 2/2/4/2 square-pixel visual project items respectively. ALL cell audio is muted; add one master track manually. These layouts do not synchronize, track faces, loop sources, or select speakers. Short sources end naturally. A source that contains the destination comp can cause nesting errors; select independent source items.
12 (56–60): absolute stereo gain, audio fades, chapter duration assignment, chapter report, and timed-marker TSV import. Gain is not loudness normalization. Fades require static audio levels and enough visible duration. Timed marker TSV has header start_seconds, duration_seconds, label; positions snap to frames and existing-frame collisions are rejected. Marker durations can overlap. Chapter-duration assignment modifies existing marker durations.
13 (61–65): quote card, sponsor card, event cards, scrolling credits, progress bar. Fixed card layouts use default host font and point text: manually wrap long strings. Credits scroll uses calculated text bounds; visually check beginning/end and font changes. Progress bar spans full comp duration.
14 (66–70): elapsed timer, numbered list, timed guest titles, corner logo, repeated source. Timer uses Source Text expression; check nonzero comp display start times. List accepts 1–8 items. Guest titles use start_seconds, end_seconds, name, role TSV and may overlap. Logo requires an open comp plus one visual Project selection; video logos do not automatically loop. Repeated sources retain audio and can have visible/audible seams.
15 (71–75): lock guide layers, hide video-disabled layers using shy state, remove empty folders after confirmation, group selected comps, script launcher. Disabled video can still carry audible audio; shy does not mute it. Empty-folder cleanup takes a snapshot and leaves parents newly emptied during this pass. No disk folders/media are deleted. Launcher runs one chosen script and closes. Do not use launcher while an unrelated modal dialog is open.

## TSV files
UTF-8 with literal tabs, one header line (skipped), and no embedded tabs/newlines in a cell. Blank rows ignored. Fictional examples included. Timed examples need >=7-second comp for guest titles. Whole input is validated before changes where practical; Adobe runtime errors can still cause partial results.

## Status / checks
No Adobe host available during development. Node syntax checks and mock behavior tests do not prove ExtendScript or Adobe runtime compatibility. Actual AE version, OS, visual layout, audio, UI launcher and rendering remain unverified. Do not describe this source preview as a tested commercial release.
Run `node verify.js` for included automated checks. See TEST_PLAN.md for friend testing.

## AI connection
Claude/OpenAI can generate input data or edit code. A live connection to execute inside Adobe is not included. These tools can form the action layer of a later adapter.
