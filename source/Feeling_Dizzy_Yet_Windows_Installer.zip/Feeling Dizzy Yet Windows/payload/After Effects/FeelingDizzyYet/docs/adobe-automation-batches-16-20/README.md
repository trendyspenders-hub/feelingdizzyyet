# Adobe Automation Starter — batches 16–20
Version 0.5.0 • 25 new standalone After Effects JSX scripts, 76–100

No AI account or live bridge required. No Premiere scripts. No automatic speaker detection or intelligent multicam cutting. These utilities can become callable actions in a later AI integration, but are currently manual-run source scripts. Earlier batches are separate.

## Run
Extract ZIP. Use a saved project copy. After Effects > File > Scripts > Run Script File. Choose any tool or 100_All_Scripts_Launcher.jsx. The launcher discovers JSX files in its own folder; the master collection places all 100 there. No permanent installation required.
Most scripts require active comp and appropriate selected layers/properties/project items. Cancel stops further actions; runtime errors can leave partial changes. Changes are grouped for Undo where supported. No script starts rendering or saves the AE project. Script 99 explicitly writes a chosen TSV file; disk writes are not undoable.

## Batch 16: 76–80
76 centers anchors on current source bounds while compensating position for static scale/rotation; unparented 2D only, no collapsed transforms or animated transform properties. Masks/effects/changing source bounds not accounted for.
77 hex fill color on selected static text. 78 font by installed PostScript name; host may substitute. 79 manual leading. Text rewrites can normalize mixed formatting.
80 Source Text typewriter expression on static text. Character-based reveal; review complex scripts, emoji, formatting and timing. Existing Source Text animation/expressions are refused.

## Batch 17: 81–85
81 damped vertical entrance expression for static unparented 2D positions. 82 wiggle for static combined positions. These are animation effects, not stabilization or audio-reactive tools.
83 removes expressions on selected leaf properties after confirmation, retaining underlying keyframes/values.
84 changes selected keys to HOLD where supported.
85 evaluates selected numeric/color leaf properties at comp current time, then removes their animation/expressions and writes static values after confirmation. This is deliberately destructive to animation; use Undo/project copies. Locked/read-only host properties may cause runtime errors. No text/custom shapes accepted.

## Batch 18: 86–90
86 intersects selected layer in/out points with comp work area; rejects non-overlapping layers.
87 sequences selected layers in timeline index order by moving whole layer timing; no overlaps. External expressions can be affected.
88 adds transparent chapter title overlays at composition markers. 89 duplicates localized versions from supplied TSV, modifying uniquely named top-level static text layers only. Nested comps/sources stay shared; no translation is generated.
90 reports evaluated font names and locations; not installed-font or full mixed-style audit.

## Batch 19: 91–95
91 current comp audio layer inventory (not loudness analysis). 92 search project composition-marker comments, case-insensitive. 93 source dependency traversal with repeat-reference protection; expression/plugin/font/data references excluded. 94 direct usage of selected footage; not guaranteed safe-to-delete determination. 95 read-only render queue and output path report.

## Batch 20: 96–100
96 lists local output module templates using first existing queue item. 97 sets QUEUED render items' ranges to source composition work areas after confirmation; no render started. Queue edits may require manual restoration depending on host undo behavior. 98 duplicates headline variants from TSV, retaining shared nested sources. 99 exports current comp markers to UTF-8 TSV; may require Preferences > Scripting & Expressions > Allow Scripts to Write Files and Access Network (this script does not use network). Explicit overwrite confirmation is included. 100 searchable launcher for scripts in same directory; excludes both launchers from choices.

## Input
Examples use UTF-8 tabs, mandatory header line, no embedded tabs/newlines per cell. Localized rows: locale, layer_name, translated_text. Headline variants: version_name, headline. Empty replacement text allowed. Font/layout changes need visual review.

## Verification
No Adobe host available. Syntax and selected mock-host checks are provided, not Adobe certification. Runtime, UI, render, expressions, typography, localization and OS/version compatibility need testing inside After Effects before production or sale.

## Friend test checklist
Record AE/OS versions and exact errors/line numbers. Use three simple text/footage layers. Test 76 at nonuniform scale and 45-degree rotation, and verify visible position remains stable. Reject parented/3D/animated transforms. Check 77–80 text style, leading, font substitution and expression errors at first/last frames. Inspect 81–82 movement; ensure existing position animation is refused. Confirm/cancel 83 and 85 and test Undo. Check 84 hold in Graph Editor.
Compare 86–87 in/out/start times and bounds. Test 88 with long marker labels. For 89/98 create one static layer named Headline and use examples; verify source text unchanged and duplicates updated. Test duplicate names, missing layer, locked layer and animated text rejection. Compare reports 90–96 with known project. Inspect queued work-area ranges in 97; restore manually if needed. Export 99, inspect tabs/UTF-8, test cancel/overwrite, then reimport with script 60 from earlier batch. Launch 100, search, run a tool, cancel.
