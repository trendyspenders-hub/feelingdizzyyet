// Run with Node.js. Checks syntax and selected logic against a mock, NOT Adobe.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const dir=path.join(__dirname,'scripts');
for(const f of fs.readdirSync(dir))new vm.Script(fs.readFileSync(path.join(dir,f),'utf8'),{filename:f});
function runMarker(tsv,existing=[]){
 function CompItem(){};const c=new CompItem();c.duration=60;c.frameRate=30;
 const keys=existing.map(t=>({t}));c.markerProperty={get numKeys(){return keys.length},keyTime(i){return keys[i-1].t},setValueAtTime(t,v){keys.push({t,v})}};
 const messages=[];let begin=0,end=0;
 const ctx={CompItem,app:{project:{activeItem:c},beginUndoGroup(){begin++},endUndoGroup(){end++}},File:{openDialog(){return {open(){return true},read(){return tsv},close(){}}}},MarkerValue:function(v){this.comment=v},alert(v){messages.push(v)}};
 vm.runInNewContext(fs.readFileSync(path.join(dir,'05_Import_Chapter_Markers.jsx'),'utf8'),ctx);
 assert.equal(begin,end);return {keys,messages};
}
let r=runMarker('seconds\tlabel\n0\tIntro\n10\tTalk\n');assert.equal(r.keys.length,2);
r=runMarker('seconds\tlabel\n0\tIntro\n60\tBad\n');assert.equal(r.keys.length,0);
r=runMarker('seconds\tlabel\n1\tA\n1.001\tB\n');assert.equal(r.keys.length,0);
r=runMarker('seconds\tlabel\n10\tA\n',[10]);assert.equal(r.keys.length,1);
console.log('PASS: 10 syntax checks; valid marker input, invalid-range atomic validation, same-frame collision, existing-marker collision. Adobe host tests pending.');
