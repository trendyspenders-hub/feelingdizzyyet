# Adobe Automation Starter — batches 01 and 02
Version 0.1.0 · Development preview · After Effects only

## What this is
Ten standalone, editable ExtendScript (.jsx) tools. No AI account, API key, network access, or live bridge required. These scripts do not run in Premiere. Premiere tools must target your friend’s installed version and will be a separate batch. There is no automatic multicam editing in this package.

## Run
1. Extract this entire ZIP.
2. Open After Effects and a disposable project or a saved copy of your project.
3. Choose File > Scripts > Run Script File and select a .jsx file from scripts/.
4. Follow the prompts. Select Cancel to stop. Some scripts may already have changed the project; use Edit > Undo if needed.
5. Inspect the result. Scripts never save over a project or start rendering.

No permanent installation is needed. Standard AE host APIs are used; no AE version or OS has yet been certified. Source syntax is checked in Node after removing no directives (none are used), but that does not establish Adobe compatibility.

## Batch 01 — project setup
01 Project Folders: create/reuse five named root folders; existing contents stay put.
02 Import Media: select multiple files; imports individually without image-sequence detection; reports per-file failures. Does not deduplicate imports.
03 Create Composition: name, whole-pixel dimensions, frame rate and duration prompts.
04 Duplicate Composition: duplicate active composition; nested compositions and source assets remain shared.
05 Import Chapter Markers: active comp + TSV. Seconds are composition-relative, snapped to frames. Rejects invalid data, duplicate frame positions, existing-marker collisions, or out-of-range times before adding markers. Header line is required and skipped.

## Batch 02 — podcast graphics and delivery setup
06 Guest Lower Third: add two transparent text layers with opacity fades in active comp. Names/roles/timing prompted. Uses width-relative sizing; visually inspect portrait comps.
07 Episode Title Card: create 1920x1080, 30 fps title card on dark background.
08 Batch Guest Cards: create transparent 1920x1080, six-second cards from TSV.
09 Social Composition Wrappers: create vertical, square and landscape comps containing active comp, scaled to FIT. It does not crop, track faces, adapt internal graphics, or choose speakers.
10 Queue Selected Compositions: select comps in Project panel; add render jobs after confirmation. Configure output formats and paths yourself. Re-running adds more jobs. Render-queue operations may not be undoable in all hosts; remove added jobs manually if needed.

## TSV examples
Files are UTF-8 tab-separated text with one header line. No embedded tabs or newlines within cells. Blank rows are ignored. chapters.tsv assumes a composition longer than 30 seconds. guests.tsv uses fictional names. Graphics use the host default font; long text can overflow and must be reviewed.

## Testing status and first smoke test
No Adobe installation was available during development. This is a source preview, not a sale-ready certified release.
1. Record AE version, OS, and chosen script.
2. Create a fresh project; run 01 twice: expect exactly five named root folders.
3. Run 03: use defaults and expect a 60-second 1920x1080 composition.
4. Run 05 with examples/chapters.tsv: expect markers at 0, 10, 30 seconds. Repeat: expect a collision error and no added markers.
5. Run 06: inspect name, role, fades, and timing; Undo and confirm the added layers disappear.
6. Run 07 and 08: inspect text, backgrounds/transparency, and long-name behavior.
7. Activate the 60-second comp, run 09: expect three wrappers with preserved duration and fitted source.
8. Select comps in Project panel, run 10, inspect queue; remove the test jobs manually.
9. Test Cancel and invalid numbers. Verify original source media remains untouched.
10. Try 02 with a supported media file and report the import count.

## Report problems
Use TEST_REPORT.md. Include the exact error message, script filename, AE version, OS, and steps. Screenshots are optional. Do not send private footage unless authorized.

## Using Claude/OpenAI
An AI can help populate these TSV files or customize the scripts. It cannot execute these scripts inside Adobe through chat alone. Live execution requires a separate connection. No connector or MCP server is included.

## Developer references
https://helpx.adobe.com/after-effects/desktop/automate-in-after-effects/automate-animation/scripts.html
https://ae-scripting.docsforadobe.dev/
