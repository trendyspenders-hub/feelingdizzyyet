# Feeling Dizzy Yet
## Editing feature update - Premiere 0.2.0 / AE panel 0.7.0

Automatic Multicam Editor runs inside Adobe. The separate browser studio has been removed from this release. Local analysis uses audio levels, minimum shot length and sustained speaker confirmation. No account, API key, cloud request, Claude or OpenAI connection is used by this feature.

### Windows installation
1. Extract the entire Windows ZIP to a local folder. Close After Effects.
2. Run `Install Feeling Dizzy Yet.cmd` with `Setup.vbs` and `payload` beside it.
3. Setup copies files to your Local AppData folder. Choose an existing AE preferences version when offered. Open AE once and close it first if no version is found.
4. Restart AE. Open **Window > Feeling Dizzy Yet**.
5. Premiere installation uses the developer-load steps below. Windows setup prepares its files; it does not register a signed production plugin.

This unsigned installer uses Windows Script Host and VBScript. If those components are unavailable, use the manual files in `payload/After Effects` and `payload/Premiere Edition/plugin`. No security setting is changed. Updates retain dated backups. The installed uninstall shortcut moves installed files to backups; it does not remove footage or projects.

### Mac installation
1. Extract the Mac ZIP. Close After Effects.
2. In `After Effects Edition`, launch the branded installer app or `Install Feeling Dizzy Yet AE.command`.
3. Choose an AE preferences version for a per-user installation. The alternative application-folder destination can require administrator authorization.
4. Restart AE. Open **Window > Feeling Dizzy Yet**.
5. Premiere uses the developer-load steps below. The optional Prepare Premiere Edition command copies its source files into Application Support.

The app and command installers are unsigned and not notarized. macOS may block launch. Manual AE installation: copy **both** `Feeling Dizzy Yet.jsx` and the `FeelingDizzyYet` companion folder from `manual-install` into your After Effects `Scripts/ScriptUI Panels` folder. Keep them together. Restart AE. Do not disable system security to install this preview.

### Premiere 25.6+ developer loading - both platforms
Install Adobe UXP Developer Tool 2.2 or later. Enable Premiere Developer Mode in Preferences/Settings > Plugins, restart Premiere, add `Premiere Edition/plugin/manifest.json` in UXP Developer Tool, then choose **Load & Watch**. Open **Window > UXP Plugins > Feeling Dizzy Yet**. Unload the previous plugin copy before loading this replacement. Host 25.6 is the declared minimum, not a claim that every later version has been tested. This is source for developer loading, not a signed CCX.

### Premiere automatic multicam
1. Save a test project. Synchronize and trim camera files and isolated microphone WAVs to the same zero. This release does not calculate sync offsets.
2. Open a sequence with the required output frame rate and square-pixel dimensions. Use ordinary local camera media with matching frame rate, dimensions and full recording coverage. Existing sequence effects, grades, graphics, edits and track layouts are not copied to the new sequence. Source trims and interpretation overrides are not reproduced.
3. Select 2-9 camera media clips in the **Project panel**, then choose **Automatic Multicam Editor > Use selected camera media**. Review the displayed order. It determines microphone mapping. Reload the selection to change the order.
4. Choose one isolated WAV per speaker camera (2-8). For overlap coverage, enable the last camera as a separate wide shot. Choose an aligned **48 kHz / 16-bit PCM WAV master mix**, mono or stereo, with the same duration.
5. Set minimum shot, confirmation time, floor and dominance margin. Confirm the alignment/format checkbox. Choose **Analyze microphones** and review the cut list.
6. Choose **Create First Cut**. The panel writes a recovery XML internally and asks Premiere to import it, then opens the new sequence if one new sequence can be identified. No browser and no manual XML export/import are needed. Inspect the Project panel if an import is partial or ambiguous.

Output is ordinary editable video segments with master audio. It is not a native switchable multicam source, does not switch angles on an existing multicam clip, and does not preserve the source sequence's edit decisions. Premiere can show import/relink dialogs. Review imported media, stereo routing, framing and audio sync before continuing.

### After Effects automatic multicam
1. Open a saved composition with synchronized camera layers covering the recording from composition zero. Select 2-9 camera layers; leave the master audio and graphics unselected.
2. Open Feeling Dizzy Yet and click **Automatic Multicam**, or run tool **102 Automatic Multicam Editor**.
3. Set 2-8 speaker microphones. Map each isolated WAV to its camera using the dropdowns. Optionally map an additional wide camera. Confirm alignment.
4. Analyze, review the cuts, then choose **Create First Cut**. The feature duplicates the composition and adds timed camera-layer segments. Selected camera templates and their audio are disabled in the duplicate. Unselected master audio and graphics are retained. The original composition is preserved.

Use unlocked, unparented 2D camera layers at 100% stretch, without time remapping, solo or track mattes. Layer-name mapping must be unique. Complex expressions, layer-index dependencies, effects and compositing need manual inspection. A failed operation can leave a partial duplicate; use Undo or remove it. Tool 101 remains only as a compatibility importer for previously saved TSV plans.

### Audio and performance
Supported analysis WAVs: little-endian RIFF PCM 16/24/32-bit or float32, mono/stereo, 8-192 kHz. Compressed WAV and WAV extensible are rejected. Microphones must have equal starts and durations within 0.1 seconds. Export quieter bleed/noise on separate tracks where possible. A shared mixed microphone cannot reliably identify the speaker.

Premiere limits each WAV to 256 MiB in memory; use lower sample-rate analysis copies or shorter sessions. AE streams analysis files under 2 GiB. Both cap recordings at two hours and 5,000 shots. Cancellation in Premiere occurs after the current WAV, and UI pauses are possible during synchronous analysis. AE cancellation is checked during streaming. Supported frame rates: 23.976, 24, 25, 29.97, 30, 50, 59.94 and 60.

This is a first-pass editing heuristic. Laughter, crosstalk, music, gain mismatch and microphone bleed can produce wrong cuts. Silence holds the current camera; similar active levels can use the wide camera. It does not perform transcription, semantic editing, automatic reframing or lip-sync recognition.

### Test before delivery
Use the included Examples: two 20-second camera clips and isolated synthetic microphone WAVs, 1280x720 at 30 fps. Expected default cut: camera one until 10.5 seconds, then camera two. Premiere additionally needs an aligned 20-second 48 kHz/16-bit master WAV (provide your own or use the supplied demo master). Synthetic tones verify timing only, not podcast accuracy.

Check: no edits during Analyze; fresh analysis required after input changes; first-cut output preserves the original; correct camera order; no black gaps; last frame duration; sync at beginning/middle/end; one intended master mix; correct stereo routing; overlap and silence; undo/partial-import recovery; saved/reopened project; short render. Repeat on Windows and Mac and each intended Adobe version. Read AUDIT.md for the remaining validation gaps.
