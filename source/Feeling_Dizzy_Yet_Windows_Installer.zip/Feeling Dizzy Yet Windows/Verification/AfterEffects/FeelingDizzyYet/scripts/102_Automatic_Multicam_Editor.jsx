// Feeling Dizzy Yet 0.2.0 / in-editor multicam controls. No external HTML workflow.
(function(){
 var source=app.project?app.project.activeItem:null;
 if(!(source instanceof CompItem)){alert('Open a synchronized camera composition first.');return;}
 var selected=source.selectedLayers;
 if(selected.length<2||selected.length>9){alert('Select 2–9 synchronized camera layers. Keep master audio and graphics unselected.');return;}
 var coreFile=File(File($.fileName).parent.parent.fsName+'/multicam-core.jsxinc');
 if(!coreFile.exists){alert('Multicam engine missing. Reinstall the full companion folder.');return;}
 $.evalFile(coreFile);
 for(var si=1;si<=source.numLayers;si++){if(source.layer(si).solo){alert('Disable solo on all layers before using multicam.');return;}}
 var config=selected.slice(0),names=[],seen={};
 for(var i=0;i<config.length;i++){
  var l=config[i];if(l.locked||l.threeDLayer||l.parent||l.timeRemapEnabled||l.stretch!==100||!l.hasVideo||!l.source||l.solo||l.hasTrackMatte||l.isTrackMatte){alert('Use unlocked, unparented 2D camera layers, 100% speed, without remapping, solo or mattes.');return;}
  if(seen['n:'+l.name]){alert('Selected camera layer names must be unique.');return;}seen['n:'+l.name]=true;names.push(l.name);
 }
 var w=new Window('dialog','Feeling Dizzy Yet | Automatic Multicam');w.orientation='column';w.alignChildren=['fill','top'];w.margins=12;w.spacing=6;
 var title=w.add('statictext',undefined,'AUTOMATIC MULTICAM');try{title.graphics.font=ScriptUI.newFont('Arial','Bold',18);}catch(ignore){}
 w.add('statictext',undefined,'Analyze aligned isolated WAVs and build cuts here in After Effects.');
 var top=w.add('group');top.add('statictext',undefined,'Speaker microphones:');var count=top.add('dropdownlist',undefined,[]);for(var n=2;n<=Math.min(8,config.length);n++)count.add('item',String(n));count.selection=count.items.length-1;
 var mappings=w.add('panel',undefined,'CAMERA / ISOLATED MICROPHONE');mappings.orientation='column';mappings.alignChildren=['fill','top'];mappings.margins=8;mappings.spacing=4;var rows=[];
 function reset(){while(mappings.children.length)mappings.remove(mappings.children[0]);rows=[];var c=Number(count.selection.text);for(var i=0;i<c;i++){var row=mappings.add('group'),choose=row.add('dropdownlist',undefined,names);choose.selection=i;choose.preferredSize=[190,22];var browse=row.add('button',undefined,'Choose WAV');var label=row.add('statictext',undefined,'No file selected');label.preferredSize=[220,22];var data={camera:choose,file:null,label:label,browse:browse};rows.push(data);(function(d){browse.onClick=function(){if(busy)return;var f=File.openDialog('Choose isolated microphone WAV');if(f){d.file=f;d.label.text=f.name;invalidate();}};choose.onChange=invalidate;}(data));}w.layout.layout(true);invalidate();}
 var wideRow=w.add('group'),useWide=wideRow.add('checkbox',undefined,'Wide camera for overlap'),wide=wideRow.add('dropdownlist',undefined,names);wide.selection=config.length-1;useWide.value=config.length===9;
 var settings=w.add('group');function input(parent,label,value,width){var g=parent.add('group');g.orientation='column';g.alignChildren=['left','top'];g.add('statictext',undefined,label);var x=g.add('edittext',undefined,value);x.preferredSize=[width||100,24];x.onChanging=invalidate;return x;}
 var min=input(settings,'Min shot (s)','2.5'),confirmTime=input(settings,'Confirm (s)','0.5'),floor=input(settings,'Floor dBFS','-40'),margin=input(settings,'Dominance dB','6');
 var aligned=w.add('checkbox',undefined,'All microphones and camera layers are aligned to composition zero.');
 var progress=w.add('progressbar',undefined,0,100);progress.preferredSize=[600,12];var status=w.add('statictext',undefined,'Ready. No project changes until Create First Cut.');status.preferredSize=[610,24];
 var output=w.add('edittext',undefined,'',{multiline:true,readonly:true,scrolling:true});output.preferredSize=[610,80];
 var actions=w.add('group'),analyze=actions.add('button',undefined,'Analyze microphones'),apply=actions.add('button',undefined,'Create First Cut'),cancel=actions.add('button',undefined,'Close');
 var plan=null,cameraMap=null,signature=null,busy=false,cancelled=false;
 function invalidate(){if(busy)return;plan=null;apply.enabled=false;output.text='';}
 function snapshot(){var a=[];for(var j=0;j<config.length;j++){var l=config[j];a.push(l.index+'|'+l.name+'|'+l.inPoint+'|'+l.outPoint+'|'+l.startTime+'|'+l.stretch+'|'+l.enabled+'|'+l.audioEnabled);}return a.join('\n')+'|'+source.duration+'|'+source.frameRate;}
 count.onChange=reset;useWide.onClick=invalidate;wide.onChange=invalidate;aligned.onClick=invalidate;
 w.onClose=function(){if(busy){cancelled=true;status.text='Cancelling...';return false;}return true;};
 cancel.onClick=function(){if(busy){cancelled=true;status.text='Cancelling...';}else w.close();};
 analyze.onClick=function(){
  if(busy)return;busy=true;cancelled=false;apply.enabled=false;analyze.enabled=false;plan=null;var controls=[count,useWide,wide,min,confirmTime,floor,margin,aligned];for(var z=0;z<controls.length;z++)controls[z].enabled=false;for(var q=0;q<rows.length;q++){rows[q].camera.enabled=false;rows[q].browse.enabled=false;}
  try{
   if(app.project.activeItem!==source)throw new Error('Source composition changed. Reopen the tool.');if(!aligned.value)throw new Error('Confirm aligned camera layers and WAVs.');
   var map=[],used={},files=[],usedFiles={};for(var j=0;j<rows.length;j++){if(!rows[j].file)throw new Error('Choose one WAV per speaker.');var fileKey='f:'+rows[j].file.fsName;if(usedFiles[fileKey])throw new Error('Choose a different WAV for each speaker.');usedFiles[fileKey]=true;var idx=rows[j].camera.selection.index;if(used['c'+idx])throw new Error('Each microphone needs a different camera.');used['c'+idx]=true;map.push(config[idx]);files.push(rows[j].file);}
   if(useWide.value){var wideIndex=wide.selection.index;if(used['c'+wideIndex])throw new Error('Wide camera must differ from speaker cameras.');map.push(config[wideIndex]);}
   var analyses=[];for(var j=0;j<files.length;j++){var f=files[j];if(f.length>2147483647)throw new Error('Use analysis WAV files under 2 GiB.');f.encoding='BINARY';if(!f.open('r'))throw new Error('Cannot open '+f.name);try{analyses.push(FDYMulticam.analyzeReader(f,.05,function(value){progress.value=100*(j+value)/files.length;status.text='Analyzing microphone '+(j+1)+' / '+files.length;w.update();return !cancelled;}));}finally{f.close();}if(cancelled)throw new Error('Analysis cancelled.');}
   var numeric=[min.text,confirmTime.text,floor.text,margin.text];for(var ni=0;ni<numeric.length;ni++)if(numeric[ni].replace(/\s/g,'')==='')throw new Error('Enter every numeric setting.');
   var result=FDYMulticam.planCuts(analyses,{fps:source.frameRate,minShot:Number(min.text),confirm:Number(confirmTime.text),floor:Number(floor.text),dominance:Number(margin.text),wide:useWide.value?rows.length:null});
   if(result.duration>source.duration+.001)throw new Error('Audio extends past source composition.');
   for(var s=0;s<result.shots.length;s++){var cue=result.shots[s],cam=map[cue.camera];if(cam.inPoint>cue.startFrame/result.fps+.001||cam.outPoint<cue.endFrame/result.fps-.001)throw new Error('Camera does not cover required shot: '+cam.name);}
   plan=result;cameraMap=map;signature=snapshot();
   var lines=[result.shots.length+' shots | '+result.duration.toFixed(2)+' seconds'];for(var k=0;k<Math.min(result.shots.length,100);k++){var cue=result.shots[k];lines.push((cue.startFrame/result.fps).toFixed(2)+' - '+(cue.endFrame/result.fps).toFixed(2)+'s | '+map[cue.camera].name);}output.text=lines.join('\n');status.text='Analysis ready. Review the cuts, then create the duplicate.';
  }catch(e){plan=null;status.text='Analysis stopped: '+e.toString();output.text='No first cut created.';}
  finally{busy=false;analyze.enabled=true;apply.enabled=!!plan;for(var z=0;z<controls.length;z++)controls[z].enabled=true;for(var q=0;q<rows.length;q++){rows[q].camera.enabled=true;rows[q].browse.enabled=true;}}
 };
 apply.onClick=function(){if(!plan||busy)return;var begun=false,created=null;
  try{if(app.project.activeItem!==source||snapshot()!==signature)throw new Error('Composition changed after analysis. Analyze again.');if(!confirm('Create a NEW composition with '+plan.shots.length+' video cuts? Selected camera audio will be muted in the duplicate. Unselected master audio and graphics are retained.'))return;
   app.beginUndoGroup('Feeling Dizzy Yet: In-editor automatic multicam');begun=true;created=source.duplicate();created.name=source.name+' - FDY First Cut';created.duration=plan.duration;var templates=[];for(var j=0;j<cameraMap.length;j++)templates.push(created.layer(cameraMap[j].index));for(var j=0;j<config.length;j++){var l=created.layer(config[j].index);l.enabled=false;if(l.hasAudio)l.audioEnabled=false;}
   for(var j=0;j<plan.shots.length;j++){var cue=plan.shots[j],copy=templates[cue.camera].duplicate();copy.name='FDY '+(j+1)+' | '+cameraMap[cue.camera].name;copy.enabled=true;if(copy.hasAudio)copy.audioEnabled=false;copy.inPoint=cue.startFrame/plan.fps;copy.outPoint=cue.endFrame/plan.fps;}
   created.openInViewer();plan=null;apply.enabled=false;status.text='First cut created. Inspect audio sync and render output.';
  }catch(e){alert(e.toString()+(created?'\nA partial duplicate may exist. Use Undo or remove it.':''));}finally{if(begun)app.endUndoGroup();}
 };
 reset();apply.enabled=false;w.center();w.show();
}());
