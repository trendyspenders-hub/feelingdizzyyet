// Adobe Automation Starter 0.3.0 | After Effects only | MIT
(function(){

function ask(q,d){var x=prompt(q,d);if(x===null)throw new Error("Cancelled.");return x;}
function num(q,d,min,max){var s=ask(q,String(d)),x=Number(s);if(!s.replace(/\s/g,"")||!isFinite(x)||x<min||x>max)throw new Error("Invalid number: "+q);return x;}
function active(){var c=app.project.activeItem;if(!(c instanceof CompItem))throw new Error("Open a composition first.");return c;}
function sel(c){var a=c.selectedLayers;if(!a.length)throw new Error("Select layers first.");for(var i=0;i<a.length;i++)if(a[i].locked)throw new Error("Unlock selected layers first.");return a;}
function prop(l,n){return l.property("ADBE Transform Group").property(n);}
function staticProp(p){if(!p||p.numKeys||p.expressionEnabled)throw new Error("Property must have no keyframes or enabled expression.");}
function simple2D(l){if(l.threeDLayer||l.parent)throw new Error("Use unparented 2D layers: "+l.name);var p=prop(l,"ADBE Position");if(p.dimensionsSeparated)throw new Error("Separate Dimensions is unsupported: "+l.name);}
function txt(c,s,size,pos){var l=c.layers.addText(s),p=l.property("ADBE Text Properties").property("ADBE Text Document"),d=p.value;d.fontSize=size;d.applyFill=true;d.fillColor=[1,1,1];d.applyStroke=false;p.setValue(d);prop(l,"ADBE Position").setValue(pos);return l;}
function report(title,s){var w=new Window("dialog",title);var b=w.add("edittext",undefined,s,{multiline:true,scrolling:true});b.preferredSize=[720,440];w.add("button",undefined,"Close",{name:"ok"});w.show();}
function readFile(){var f=File.openDialog("Choose UTF-8 input file");if(!f)throw new Error("Cancelled.");f.encoding="UTF-8";if(!f.open("r"))throw new Error("Cannot open input.");try{return f.read().replace(/^\uFEFF/,"").replace(/\r\n?/g,"\n");}finally{f.close();}}
function rows(){var a=readFile().split("\n"),r=[];for(var i=1;i<a.length;i++)if(a[i].replace(/\s/g,""))r.push(a[i].split("\t"));return r;}
function captions(c,cues){for(var i=0;i<cues.length;i++){var q=cues[i];if(!isFinite(q.start)||!isFinite(q.end)||q.start<0||q.end<=q.start||q.end>c.duration||!q.text)throw new Error("Invalid caption cue "+(i+1));}for(var j=0;j<cues.length;j++){var q=cues[j],l=c.layers.addBoxText([c.width*.84,c.height*.25]);l.name="Caption "+(j+1);var p=l.property("ADBE Text Properties").property("ADBE Text Document"),d=p.value;d.text=q.text;d.fontSize=c.width*.032;d.applyFill=true;d.fillColor=[1,1,1];d.applyStroke=true;d.strokeColor=[0,0,0];d.strokeWidth=2;d.justification=ParagraphJustification.CENTER_JUSTIFY;p.setValue(d);prop(l,"ADBE Position").setValue([c.width*.08,c.height*.70]);l.inPoint=q.start;l.outPoint=q.end;}}

var begun=false;try{if(!app.project)throw new Error("Open a project first.");app.beginUndoGroup("27_Ease_Selected_Keyframes");begun=true;
var c=active(),ps=c.selectedProperties,list=[];for(var i=0;i<ps.length;i++){var p=ps[i];if(p.propertyType===PropertyType.PROPERTY&&p.selectedKeys.length){var t=p.propertyValueType;if(t!==PropertyValueType.OneD&&t!==PropertyValueType.TwoD&&t!==PropertyValueType.ThreeD&&t!==PropertyValueType.TwoD_SPATIAL&&t!==PropertyValueType.ThreeD_SPATIAL)throw new Error("Select numeric properties only.");if(p.expressionEnabled)throw new Error("Disable selected property expressions first.");list.push(p);}}if(!list.length)throw new Error("Select numeric keyframes first.");var influence=num("Ease influence percent",33.33,.1,100);for(var j=0;j<list.length;j++){var p=list[j],keys=p.selectedKeys,t=p.propertyValueType,n=(t===PropertyValueType.TwoD?2:t===PropertyValueType.ThreeD?3:1);for(var k=0;k<keys.length;k++){var ease=[];for(var d=0;d<n;d++)ease.push(new KeyframeEase(0,influence));p.setTemporalEaseAtKey(keys[k],ease,ease);}}
}catch(e){alert("27_Ease_Selected_Keyframes\n"+e.toString()+"\nUse Edit > Undo if changes were made.");}finally{if(begun)app.endUndoGroup();}
}());
