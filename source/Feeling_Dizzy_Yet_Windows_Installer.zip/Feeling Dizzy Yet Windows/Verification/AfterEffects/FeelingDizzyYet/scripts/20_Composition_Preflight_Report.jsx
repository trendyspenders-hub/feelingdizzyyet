// Adobe Automation Starter 0.2.0 | After Effects only | MIT
(function(){

function ask(label,value){var s=prompt(label,value);if(s===null)throw new Error("Cancelled.");return s;}
function num(label,value,min,max){var s=ask(label,String(value)),n=Number(s);if(!s.replace(/\s/g,"")||!isFinite(n)||n<min||n>max)throw new Error("Invalid number: "+label);return n;}
function active(){var c=app.project.activeItem;if(!(c instanceof CompItem))throw new Error("Open a composition first.");return c;}
function selected(c){var a=c.selectedLayers;if(!a.length)throw new Error("Select layers first.");for(var i=0;i<a.length;i++)if(a[i].locked)throw new Error("Unlock selected layers first.");return a;}
function opacity(l){return l.property("ADBE Transform Group").property("ADBE Opacity");}
function textProp(l){var p=l.property("ADBE Text Properties");return p?p.property("ADBE Text Document"):null;}
function plainText(p){if(p.numKeys||p.expressionEnabled)throw new Error("Animated or expression-driven Source Text is not supported.");}
function readRows(){var f=File.openDialog("Choose UTF-8 TSV");if(!f)throw new Error("Cancelled.");f.encoding="UTF-8";if(!f.open("r"))throw new Error("Cannot open TSV.");var s;try{s=f.read();}finally{f.close();}var lines=s.replace(/^\uFEFF/,"").replace(/\r\n?/g,"\n").split("\n"),r=[];for(var i=1;i<lines.length;i++)if(lines[i].replace(/\s/g,""))r.push(lines[i].split("\t"));return r;}
function showReport(title,body){var w=new Window("dialog",title);w.orientation="column";w.alignChildren=["fill","fill"];var box=w.add("edittext",undefined,body,{multiline:true,scrolling:true});box.preferredSize=[680,420];w.add("button",undefined,"Close",{name:"ok"});w.show();}

var begun=false;try{if(!app.project)throw new Error("Open a project first.");app.beginUndoGroup("20_Composition_Preflight_Report");begun=true;
var c=active(),lines=["Composition: "+c.name,"Size: "+c.width+" x "+c.height,"FPS: "+c.frameRate,"Duration: "+c.duration+" seconds","Layers: "+c.numLayers,"","Review flags (heuristics, not delivery certification):"],count=0;for(var i=1;i<=c.numLayers;i++){var l=c.layer(i),flags=[];if(!l.enabled)flags.push("video disabled");if(l.guideLayer)flags.push("guide layer");if(l.solo)flags.push("solo enabled");if(l.inPoint<0||l.outPoint>c.duration)flags.push("extends outside composition");if(l.source instanceof FootageItem&&l.source.footageMissing)flags.push("missing source footage");var p=textProp(l);if(p){var d=p.value;if(!d.text.replace(/\s/g,""))flags.push("empty text");}if(flags.length){lines.push("Layer "+i+" ["+l.name+"]: "+flags.join(", "));count++;}}if(!count)lines.push("No listed flags detected.");lines.push("","Does not inspect nested comps, audio loudness, font availability, actual frame pixels, caption accuracy, or export configuration.");showReport("Composition preflight",lines.join("\n"));
}catch(e){alert("20_Composition_Preflight_Report\n"+e.toString()+"\nUse Edit > Undo if changes were made.");}finally{if(begun)app.endUndoGroup();}
}());
