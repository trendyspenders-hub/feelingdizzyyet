// Adobe Automation Starter 0.2.0 | After Effects only | MIT
(function(){

function ask(label,value){var s=prompt(label,value);if(s===null)throw new Error("Cancelled.");return s;}
function num(label,value,min,max){var s=ask(label,String(value)),n=Number(s);if(!s.replace(/\s/g,"")||!isFinite(n)||n<min||n>max)throw new Error("Invalid number: "+label);return n;}
function active(){var c=app.project.activeItem;if(!(c instanceof CompItem))throw new Error("Open a composition first.");return c;}
function selected(c){var a=c.selectedLayers;if(!a.length)throw new Error("Select layers first.");for(var i=0;i<a.length;i++)if(a[i].locked)throw new Error("Unlock selected layers first.");return a;}
function opacity(l){return l.property("ADBE Transform Group").property("ADBE Opacity");}
function textProp(l){var p=l.property("ADBE Text Properties");return p?p.property("ADBE Text Document"):null;}
function plainText(p){if(p.numKeys||p.expressionEnabled)throw new Error("Animated or expression-driven Source Text is not supported.");}
function readRows(){var f=File.openDialog("Choose UTF-8 TSV");if(!f)throw new Error("Cancelled.");f.encoding="UTF-8";if(!f.open("r"))throw new Error("Cannot open TSV.");var s;try{s=f.read();}finally{f.close();}var lines=s.replace(/^\uFEFF/,"").replace(/\r\n?/g,"\n").split("\n"),r=[];for(var i=1;i<lines.length;i++)if(lines[i].replace(/\s/g,""))r.push(lines[i].split("\t"));return r;}
function showReport(title,body){var w=new Window("dialog",title);w.orientation="column";w.alignChildren=["fill","fill"];var box=w.add("edittext",undefined,body,{multiline:true,scrolling:true});box.preferredSize=[680,420];w.add("button",undefined,"Close",{name:"ok"});w.show();}

var begun=false;try{if(!app.project)throw new Error("Open a project first.");app.beginUndoGroup("13_Fade_Selected_Layers");begun=true;
var c=active(),a=selected(c),duration=num("Fade duration seconds",0.3,0.001,60);for(var i=0;i<a.length;i++){var l=a[i],p=opacity(l),begin=Math.max(0,l.inPoint),end=Math.min(c.duration,l.outPoint);if(!p||p.numKeys||p.expressionEnabled)throw new Error("Opacity must have no keyframes or enabled expression: "+l.name);if(end-begin<2*duration)throw new Error("Layer too short for both fades: "+l.name);}for(var j=0;j<a.length;j++){var l=a[j],p=opacity(l),level=p.value,b=Math.max(0,l.inPoint),e=Math.min(c.duration,l.outPoint);p.setValueAtTime(b,0);p.setValueAtTime(b+duration,level);if(e-duration>b+duration)p.setValueAtTime(e-duration,level);p.setValueAtTime(e,0);}
}catch(e){alert("13_Fade_Selected_Layers\n"+e.toString()+"\nUse Edit > Undo if changes were made.");}finally{if(begun)app.endUndoGroup();}
}());
