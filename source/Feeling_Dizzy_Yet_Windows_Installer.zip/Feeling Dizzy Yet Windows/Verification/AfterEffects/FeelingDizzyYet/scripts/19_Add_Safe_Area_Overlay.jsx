// Adobe Automation Starter 0.2.0 | After Effects only | MIT
(function(){

function ask(label,value){var s=prompt(label,value);if(s===null)throw new Error("Cancelled.");return s;}
function num(label,value,min,max){var s=ask(label,String(value)),n=Number(s);if(!s.replace(/\s/g,"")||!isFinite(n)||n<min||n>max)throw new Error("Invalid number: "+label);return n;}
function active(){var c=app.project.activeItem;if(!(c instanceof CompItem))throw new Error("Open a composition first.");return c;}
function selected(c){var a=c.selectedLayers;if(!a.length)throw new Error("Select layers first.");for(var i=0;i<a.length;i++)if(a[i].locked)throw new Error("Unlock selected layers first.");return a;}
function opacity(l){return l.property("ADBE Transform Group").property("ADBE Opacity");}
function textProp(l){var p=l.property("ADBE Text Properties");return p?p.property("ADBE Text Document"):null;}
function plainText(p){if(p.numKeys||p.expressionEnabled)throw new Error("Animated or expression-driven Source Text is not supported.");}
function readRows(){var f=File.openDialog("Choose UTF-8 TSV");if(!f)throw new Error("Cancelled.");f.encoding="UTF-8";if(!f.open("r"))throw new Error("Cannot open TSV.");var s;try{s=f.read();}finally{f.close();}var lines=s.replace(/^\uFEFF/,"").replace(/\r\n?/g,"\n").split("\n"),r=[];for(var i=1;i<lines.length;i++)if(lines[i].replace(/\s/g,""))r.push(lines[i].split("\t"));return r;}
function showReport(title,body){var w=new Window("dialog",title);w.orientation="column";w.alignChildren=["fill","fill"];var box=w.add("edittext",undefined,body,{multiline:true,scrolling:true});box.preferredSize=[680,420];w.add("button",undefined,"Close",{name:"ok"});w.show();}

var begun=false;try{if(!app.project)throw new Error("Open a project first.");app.beginUndoGroup("19_Add_Safe_Area_Overlay");begun=true;
var c=active(),margin=num("Inset from each edge percent",10,1,40)/100;function line(name,w,h,x,y){var l=c.layers.addSolid([0,1,.65],name,w,h,1,c.duration);l.guideLayer=true;l.property("ADBE Transform Group").property("ADBE Position").setValue([x,y]);return l;}var x=Math.round(c.width*margin),y=Math.round(c.height*margin),w=Math.max(4,c.width-2*x),h=Math.max(4,c.height-2*y);line("Safe area - top",w,4,c.width/2,y);line("Safe area - bottom",w,4,c.width/2,c.height-y);line("Safe area - left",4,h,x,c.height/2);line("Safe area - right",4,h,c.width-x,c.height/2);alert("Four guide layers added. Standard AE rendering excludes them; verify guide-layer settings. This is a user-defined inset, not a platform-certified safe area.");
}catch(e){alert("19_Add_Safe_Area_Overlay\n"+e.toString()+"\nUse Edit > Undo if changes were made.");}finally{if(begun)app.endUndoGroup();}
}());
