// Adobe Automation Starter 0.3.0 | After Effects only | MIT
(function(){

function ask(q,d){var x=prompt(q,d);if(x===null)throw new Error("Cancelled.");return x;}
function num(q,d,min,max){var s=ask(q,String(d)),x=Number(s);if(!s.replace(/\s/g,"")||!isFinite(x)||x<min||x>max)throw new Error("Invalid number: "+q);return x;}
function active(){var c=app.project.activeItem;if(!(c instanceof CompItem))throw new Error("Open a composition first.");return c;}
function sel(c){var a=c.selectedLayers;if(!a.length)throw new Error("Select layers first.");for(var i=0;i<a.length;i++)if(a[i].locked)throw new Error("Unlock selected layers first.");return a;}
function prop(l,n){return l.property("ADBE Transform Group").property(n);}
function staticProp(p){if(!p||p.numKeys||p.expressionEnabled)throw new Error("Property must have no keyframes or enabled expression.");}
function simple2D(l){if(l.threeDLayer||l.parent)throw new Error("Use unparented 2D layers: "+l.name);var p=prop(l,"ADBE Position");if(p.dimensionsSeparated)throw new Error("Separate Dimensions is unsupported: "+l.name);}
function txt(c,s,size,pos){var l=c.layers.addText(s),p=l.property("ADBE Text Properties").property("ADBE Text Document"),d=p.value;d.fontSize=size;d.applyFill=true;d.fillColor=[1,1,1];d.applyStroke=false;p.setValue(d);prop(l,"ADBE Position").setValue(pos);return l;}
function report(title,s){var w=new Window("dialog",title);var b=w.add("edittext",undefined,s,{multiline:true,scrolling:true});b.preferredSize=[720,440];w.add("button",undefined,"Close",{name:"ok"});w.show();}
function readFile(){var f=File.openDialog("Choose UTF-8 input file");if(!f)throw new Error("Cancelled.");f.encoding="UTF-8";if(!f.open("r"))throw new Error("Cannot open input.");try{return f.read().replace(/^\uFEFF/,"").replace(/\r\n?/g,"\n");}finally{f.close();}}
function rows(){var a=readFile().split("\n"),r=[];for(var i=1;i<a.length;i++)if(a[i].replace(/\s/g,""))r.push(a[i].split("\t"));return r;}
function captions(c,cues){for(var i=0;i<cues.length;i++){var q=cues[i];if(!isFinite(q.start)||!isFinite(q.end)||q.start<0||q.end<=q.start||q.end>c.duration||!q.text)throw new Error("Invalid caption cue "+(i+1));}for(var j=0;j<cues.length;j++){var q=cues[j],l=c.layers.addBoxText([c.width*.84,c.height*.25]);l.name="Caption "+(j+1);var p=l.property("ADBE Text Properties").property("ADBE Text Document"),d=p.value;d.text=q.text;d.fontSize=c.width*.032;d.applyFill=true;d.fillColor=[1,1,1];d.applyStroke=true;d.strokeColor=[0,0,0];d.strokeWidth=2;d.justification=ParagraphJustification.CENTER_JUSTIFY;p.setValue(d);prop(l,"ADBE Position").setValue([c.width*.08,c.height*.70]);l.inPoint=q.start;l.outPoint=q.end;}}

var begun=false;try{if(!app.project)throw new Error("Open a project first.");app.beginUndoGroup("25_Distribute_Selected_Layers");begun=true;
var c=active(),a=sel(c),axis=ask("Distribute anchor points: x or y","x");if(a.length<3)throw new Error("Select at least three layers.");if(axis!=="x"&&axis!=="y")throw new Error("Use x or y.");var idx=axis==="x"?0:1;for(var i=0;i<a.length;i++){simple2D(a[i]);staticProp(prop(a[i],"ADBE Position"));}a.sort(function(x,y){return prop(x,"ADBE Position").value[idx]-prop(y,"ADBE Position").value[idx];});var lo=prop(a[0],"ADBE Position").value[idx],hi=prop(a[a.length-1],"ADBE Position").value[idx];for(var j=1;j<a.length-1;j++){var p=prop(a[j],"ADBE Position"),v=p.value;v[idx]=lo+(hi-lo)*j/(a.length-1);p.setValue(v);}
}catch(e){alert("25_Distribute_Selected_Layers\n"+e.toString()+"\nUse Edit > Undo if changes were made.");}finally{if(begun)app.endUndoGroup();}
}());
