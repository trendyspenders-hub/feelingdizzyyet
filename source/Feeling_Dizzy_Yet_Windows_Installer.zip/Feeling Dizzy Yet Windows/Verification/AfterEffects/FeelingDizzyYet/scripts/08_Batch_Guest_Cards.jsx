// Adobe Automation Starter 0.1.0 - After Effects only
// Source provided under MIT; host testing pending.
(function () {

function stop(){throw new Error("Cancelled; no further actions performed.");}
function ask(label,def){var v=prompt(label,def);if(v===null)stop();return v;}
function number(label,def,min,max){var s=ask(label,String(def));var v=Number(s);if(s.replace(/\s/g,"")===""||!isFinite(v)||v<min||v>max)throw new Error("Invalid number: "+label);return v;}
function comp(){var c=app.project.activeItem;if(!(c instanceof CompItem))throw new Error("Open a composition first.");return c;}
function folder(name){for(var i=1;i<=app.project.numItems;i++){var x=app.project.item(i);if(x instanceof FolderItem&&x.name===name&&x.parentFolder===app.project.rootFolder)return x;}return app.project.items.addFolder(name);}
function unique(name){var n=name,k=2,found;do{found=false;for(var i=1;i<=app.project.numItems;i++)if(app.project.item(i).name===n){found=true;break;}if(found)n=name+" "+k++;}while(found);return n;}
function text(c,value,size,pos){var l=c.layers.addText(value);var p=l.property("ADBE Text Properties").property("ADBE Text Document"),d=p.value;d.fontSize=size;d.applyFill=true;d.fillColor=[1,1,1];d.applyStroke=false;p.setValue(d);l.property("ADBE Transform Group").property("ADBE Position").setValue(pos);return l;}
function readTSV(){var f=File.openDialog("Choose a UTF-8 TSV file");if(!f)stop();f.encoding="UTF-8";if(!f.open("r"))throw new Error("Cannot read file.");var raw;try{raw=f.read();}finally{f.close();}var lines=raw.replace(/^\uFEFF/,"").replace(/\r\n/g,"\n").replace(/\r/g,"\n").split("\n"),out=[];for(var i=1;i<lines.length;i++)if(lines[i].replace(/\s/g,"")!=="")out.push(lines[i].split("\t"));return out;}

var begun=false;try {
if(!app.project)app.newProject();
app.beginUndoGroup("08_Batch_Guest_Cards");begun=true;
var rows=readTSV();for(var i=0;i<rows.length;i++)if(rows[i].length!==2||!rows[i][0]||!rows[i][1])throw new Error("Each TSV row needs name<TAB>role.");var dest=folder("03 Graphics");for(var j=0;j<rows.length;j++){var c=app.project.items.addComp(unique("Guest Card - "+rows[j][0]),1920,1080,1,6,30);c.parentFolder=dest;text(c,rows[j][0],72,[140,820]);text(c,rows[j][1],40,[145,890]);}alert("Created "+rows.length+" transparent guest cards. Review text fit before rendering.");
} catch(e){alert("08_Batch_Guest_Cards\n"+e.toString()+"\nIf changes were made, use Edit > Undo.");}
finally {if(begun)app.endUndoGroup();}
}());
