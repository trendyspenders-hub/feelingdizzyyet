// Adobe Automation Starter 0.2.0 | After Effects only | MIT
(function(){

function ask(label,value){var s=prompt(label,value);if(s===null)throw new Error("Cancelled.");return s;}
function num(label,value,min,max){var s=ask(label,String(value)),n=Number(s);if(!s.replace(/\s/g,"")||!isFinite(n)||n<min||n>max)throw new Error("Invalid number: "+label);return n;}
function active(){var c=app.project.activeItem;if(!(c instanceof CompItem))throw new Error("Open a composition first.");return c;}
function selected(c){var a=c.selectedLayers;if(!a.length)throw new Error("Select layers first.");for(var i=0;i<a.length;i++)if(a[i].locked)throw new Error("Unlock selected layers first.");return a;}
function opacity(l){return l.property("ADBE Transform Group").property("ADBE Opacity");}
function textProp(l){var p=l.property("ADBE Text Properties");return p?p.property("ADBE Text Document"):null;}
function plainText(p){if(p.numKeys||p.expressionEnabled)throw new Error("Animated or expression-driven Source Text is not supported.");}
function readRows(){var f=File.openDialog("Choose UTF-8 TSV");if(!f)throw new Error("Cancelled.");f.encoding="UTF-8";if(!f.open("r"))throw new Error("Cannot open TSV.");var s;try{s=f.read();}finally{f.close();}var lines=s.replace(/^\uFEFF/,"").replace(/\r\n?/g,"\n").split("\n"),r=[];for(var i=1;i<lines.length;i++)if(lines[i].replace(/\s/g,""))r.push(lines[i].split("\t"));return r;}
function showReport(title,body){var w=new Window("dialog",title);w.orientation="column";w.alignChildren=["fill","fill"];var box=w.add("edittext",undefined,body,{multiline:true,scrolling:true});box.preferredSize=[680,420];w.add("button",undefined,"Close",{name:"ok"});w.show();}

var begun=false;try{if(!app.project)throw new Error("Open a project first.");app.beginUndoGroup("18_Add_Review_Watermark");begun=true;
var c=active(),value=ask("Review watermark text","DRAFT - REVIEW ONLY"),alpha=num("Opacity percent",25,1,100),l=c.layers.addText(value);l.name="Review Watermark";var p=textProp(l),d=p.value;d.fontSize=c.width*.035;d.applyFill=true;d.fillColor=[1,1,1];d.applyStroke=false;d.justification=ParagraphJustification.CENTER_JUSTIFY;p.setValue(d);l.property("ADBE Transform Group").property("ADBE Position").setValue([c.width/2,c.height*.94]);opacity(l).setValue(alpha);l.inPoint=0;l.outPoint=c.duration;alert("Watermark added as a rendered text layer. It is NOT a guide layer. Check fit and placement.");
}catch(e){alert("18_Add_Review_Watermark\n"+e.toString()+"\nUse Edit > Undo if changes were made.");}finally{if(begun)app.endUndoGroup();}
}());
