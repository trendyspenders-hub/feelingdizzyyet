// Adobe Automation Starter 0.4.0 | After Effects only | MIT
(function(){

function ask(q,d){var s=prompt(q,d);if(s===null)throw new Error("Cancelled.");return s;}
function num(q,d,lo,hi){var s=ask(q,String(d)),v=Number(s);if(!s.replace(/\s/g,"")||!isFinite(v)||v<lo||v>hi)throw new Error("Invalid number: "+q);return v;}
function active(){var c=app.project.activeItem;if(!(c instanceof CompItem))throw new Error("Open a composition first.");return c;}
function layers(c){var a=c.selectedLayers;if(!a.length)throw new Error("Select layers first.");for(var i=0;i<a.length;i++)if(a[i].locked)throw new Error("Unlock selected layers first.");return a;}
function items(){var a=app.project.selection;if(!a.length)throw new Error("Select items in Project panel first.");return a;}
function visualItems(){var a=items(),out=[];for(var i=0;i<a.length;i++){var x=a[i];if(!(x instanceof FootageItem||x instanceof CompItem)||!x.width||!x.height||x.pixelAspect!==1)throw new Error("Select square-pixel visual footage or compositions only.");out.push(x);}return out;}
function tr(l,n){return l.property("ADBE Transform Group").property(n);}
function staticProp(p){if(!p||p.numKeys||p.expressionEnabled)throw new Error("Property has keyframes or an enabled expression.");}
function rootFolder(name){for(var i=1;i<=app.project.numItems;i++){var x=app.project.item(i);if(x instanceof FolderItem&&x.name===name&&x.parentFolder===app.project.rootFolder)return x;}return app.project.items.addFolder(name);}
function newComp(name,w,h,d,fps){return app.project.items.addComp(name,w,h,1,d,fps);}
function text(c,s,size,x,y){var l=c.layers.addText(s),p=l.property("ADBE Text Properties").property("ADBE Text Document"),d=p.value;d.fontSize=size;d.applyFill=true;d.fillColor=[1,1,1];d.applyStroke=false;p.setValue(d);tr(l,"ADBE Position").setValue([x,y]);return l;}
function bg(c){c.layers.addSolid([.025,.035,.055],"Background",c.width,c.height,1,c.duration);}
function report(title,s){var w=new Window("dialog",title);var b=w.add("edittext",undefined,s,{multiline:true,scrolling:true});b.preferredSize=[720,440];w.add("button",undefined,"Close",{name:"ok"});w.show();}
function rows(){var f=File.openDialog("Choose UTF-8 TSV file");if(!f)throw new Error("Cancelled.");f.encoding="UTF-8";if(!f.open("r"))throw new Error("Cannot read file.");var raw;try{raw=f.read();}finally{f.close();}var a=raw.replace(/^\uFEFF/,"").replace(/\r\n?/g,"\n").split("\n"),r=[];for(var i=1;i<a.length;i++)if(a[i].replace(/\s/g,""))r.push(a[i].split("\t"));return r;}
function fit(l,src,w,h,fill){var s=100*(fill?Math.max(w/src.width,h/src.height):Math.min(w/src.width,h/src.height));tr(l,"ADBE Anchor Point").setValue([src.width/2,src.height/2]);tr(l,"ADBE Position").setValue([w/2,h/2]);tr(l,"ADBE Scale").setValue([s,s]);}
function layout(name,w,h,rects){var a=visualItems();if(a.length!==rects.length)throw new Error("Select exactly "+rects.length+" visual project items. Project selection order assigns cells.");var duration=num("Layout duration seconds",30,1,10800),mode=ask("Cell scaling: fit or fill","fit");if(mode!=="fit"&&mode!=="fill")throw new Error("Use fit or fill.");var c=newComp(name,w,h,duration,30);for(var i=0;i<a.length;i++){var r=rects[i],cell=newComp(name+" Cell "+(i+1),r[2],r[3],duration,30),l=cell.layers.add(a[i]);fit(l,a[i],r[2],r[3],mode==="fill");if(l.hasAudio)l.audioEnabled=false;var outer=c.layers.add(cell);tr(outer,"ADBE Position").setValue([r[0]+r[2]/2,r[1]+r[3]/2]);}c.openInViewer();alert("Layout built; ALL cell audio muted. Add one master audio track manually. Sources are not synchronized or looped. Cell order follows Project selection order.");}
function audioProp(l){if(!l.hasAudio)throw new Error("Selected layer has no audio: "+l.name);return l.property("ADBE Audio Group").property("ADBE Audio Levels");}

var begun=false;try{if(!app.project)throw new Error("Open a project first.");app.beginUndoGroup("66_Add_Elapsed_Time_Display");begun=true;
var c=active(),l=text(c,"00:00",c.width*.025,c.width*.05,c.height*.1);l.name="Elapsed Time";l.inPoint=0;l.outPoint=c.duration;var p=l.property("ADBE Text Properties").property("ADBE Text Document");p.expression='var s=Math.max(0,Math.floor(time)); var m=Math.floor(s/60); function pad(n){return n<10?"0"+n:""+n;} pad(m)+":"+pad(s%60);';alert("Added expression-driven timer. Confirm time display with nonzero composition start times.");
}catch(e){alert("66_Add_Elapsed_Time_Display\n"+e.toString()+"\nUse Edit > Undo if changes were made.");}finally{if(begun)app.endUndoGroup();}
}());
