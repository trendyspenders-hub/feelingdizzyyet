// Feeling Dizzy Yet / After Effects multicam first-cut adapter 0.1.0
// Select synchronized camera layers, then import the frame-based TSV from Multicam Studio.
(function(){
 var begun=false,created=null;
 try{
  if(!app.project||!(app.project.activeItem instanceof CompItem))throw new Error('Open your synchronized camera composition first.');
  var source=app.project.activeItem,selected=source.selectedLayers;if(selected.length<2||selected.length>9)throw new Error('Select 2–9 camera layers, including wide camera if used. Do not select master audio or graphics.');
  var map={},indexes=[];for(var i=0;i<selected.length;i++){var l=selected[i],key='cam:'+l.name;if(map[key])throw new Error('Selected camera names must be unique.');if(!l.hasVideo||!l.source||l.threeDLayer||l.parent||l.timeRemapEnabled||l.stretch!==100||l.locked)throw new Error('Use unlocked, unparented 2D camera layers at 100% speed, without time remapping.');map[key]=l;indexes.push({name:l.name,index:l.index});}
  var file=File.openDialog('Choose Feeling Dizzy Yet cut-plan TSV');if(!file)return;file.encoding='UTF-8';if(!file.open('r'))throw new Error('Cannot read cut plan.');var raw;try{raw=file.read();}finally{file.close();}
  var lines=raw.replace(/^\uFEFF/,'').replace(/\r\n?/g,'\n').split('\n');if(lines.shift()!=='start_frame\tend_frame\tcamera\tfps')throw new Error('Wrong cut-plan header. Use Multicam Studio TSV output.');
  var shots=[],last=0,fps=null;
  for(var row=0;row<lines.length;row++){if(!lines[row].replace(/\s/g,''))continue;var q=lines[row].split('\t'),s=Number(q[0]),e=Number(q[1]),f=Number(q[3]);if(q.length!==4||q[0]===''||q[1]===''||!isFinite(s)||!isFinite(e)||s%1||e%1||s!==last||e<=s||!isFinite(f)||f<=0)throw new Error('Invalid or non-contiguous shot row '+(row+1));if(fps===null)fps=f;else if(Math.abs(f-fps)>.000001)throw new Error('Mixed frame rates in cut plan.');if(!map['cam:'+q[2]])throw new Error('Select camera layer named exactly: '+q[2]);shots.push({start:s,end:e,name:q[2]});last=e;}
  if(!shots.length||shots.length>5000)throw new Error('Use 1–5000 valid shots.');if(Math.abs(source.frameRate-fps)>.001)throw new Error('Composition FPS differs from cut plan. Change comp FPS or regenerate the plan.');var duration=last/fps;if(duration>source.duration+.001)throw new Error('Plan extends past the source composition.');
  for(var j=0;j<shots.length;j++){var shot=shots[j],camera=map['cam:'+shot.name];if(camera.inPoint>shot.start/fps+.001||camera.outPoint<shot.end/fps-.001)throw new Error('Camera does not cover shot range: '+camera.name);}
  if(!confirm('Create a NEW first-cut composition with '+shots.length+' video segments?\n\nSelected cameras will be replaced by video-only cut segments in the duplicate. Unselected layers, including your master audio, are retained. Original composition is unchanged.'))return;
  app.beginUndoGroup('Feeling Dizzy Yet: Automatic multicam first cut');begun=true;created=source.duplicate();created.name=source.name+' - FDY First Cut';created.duration=duration;
  var templates={};for(var k=0;k<indexes.length;k++){var original=created.layer(indexes[k].index);templates['cam:'+indexes[k].name]=original;original.enabled=false;if(original.hasAudio)original.audioEnabled=false;}
  for(var n=0;n<shots.length;n++){var cue=shots[n],copy=templates['cam:'+cue.name].duplicate();copy.name='FDY '+(n+1)+' | '+cue.name;copy.enabled=true;if(copy.hasAudio)copy.audioEnabled=false;copy.inPoint=cue.start/fps;copy.outPoint=cue.end/fps;}
  created.openInViewer();alert('Created '+shots.length+' editable video segments.\nReview master audio, sync, overlays, camera order, cut timing and render output. This is not a native switchable multicam object.');
 }catch(e){alert('Feeling Dizzy Yet multicam\n'+e.toString()+(created?'\nA partial duplicate may exist. Use Undo or remove only the partial duplicate.':''));}
 finally{if(begun)app.endUndoGroup();}
}());
