// Adobe Automation Starter 0.2.0 | After Effects only | MIT
(function(){

function ask(label,value){var s=prompt(label,value);if(s===null)throw new Error("Cancelled.");return s;}
function num(label,value,min,max){var s=ask(label,String(value)),n=Number(s);if(!s.replace(/\s/g,"")||!isFinite(n)||n<min||n>max)throw new Error("Invalid number: "+label);return n;}
function active(){var c=app.project.activeItem;if(!(c instanceof CompItem))throw new Error("Open a composition first.");return c;}
function selected(c){var a=c.selectedLayers;if(!a.length)throw new Error("Select layers first.");for(var i=0;i<a.length;i++)if(a[i].locked)throw new Error("Unlock selected layers first.");return a;}
function opacity(l){return l.property("ADBE Transform Group").property("ADBE Opacity");}
function textProp(l){var p=l.property("ADBE Text Properties");return p?p.property("ADBE Text Document"):null;}
function plainText(p){if(p.numKeys||p.expressionEnabled)throw new Error("Animated or expression-driven Source Text is not supported.");}
function readRows(){var f=File.openDialog("Choose UTF-8 TSV");if(!f)throw new Error("Cancelled.");f.encoding="UTF-8";if(!f.open("r"))throw new Error("Cannot open TSV.");var s;try{s=f.read();}finally{f.close();}var lines=s.replace(/^\uFEFF/,"").replace(/\r\n?/g,"\n").split("\n"),r=[];for(var i=1;i<lines.length;i++)if(lines[i].replace(/\s/g,""))r.push(lines[i].split("\t"));return r;}
function showReport(title,body){var w=new Window("dialog",title);w.orientation="column";w.alignChildren=["fill","fill"];var box=w.add("edittext",undefined,body,{multiline:true,scrolling:true});box.preferredSize=[680,420];w.add("button",undefined,"Close",{name:"ok"});w.show();}

var begun=false;try{if(!app.project)throw new Error("Open a project first.");app.beginUndoGroup("17_Update_Text_From_TSV");begun=true;
var c=active(),rows=readRows(),changes=[],seen={};for(var i=0;i<rows.length;i++){var r=rows[i];if(r.length!==2||!r[0])throw new Error("Each data row requires layer_name<TAB>text.");var key="k:"+r[0];if(seen[key])throw new Error("Duplicate TSV layer name: "+r[0]);seen[key]=true;var match=null,count=0;for(var j=1;j<=c.numLayers;j++)if(c.layer(j).name===r[0]){match=c.layer(j);count++;}if(count!==1)throw new Error("Expected exactly one layer named: "+r[0]);if(match.locked)throw new Error("Unlock layer: "+r[0]);var p=textProp(match);if(!p)throw new Error("Not a text layer: "+r[0]);plainText(p);changes.push({p:p,value:r[1]});}for(var k=0;k<changes.length;k++){var d=changes[k].p.value;d.text=changes[k].value;changes[k].p.setValue(d);}alert("Updated "+changes.length+" layers. Review typography and text fit.");
}catch(e){alert("17_Update_Text_From_TSV\n"+e.toString()+"\nUse Edit > Undo if changes were made.");}finally{if(begun)app.endUndoGroup();}
}());
