// Adobe Automation Starter 0.2.0 | After Effects only | MIT
(function(){

function ask(label,value){var s=prompt(label,value);if(s===null)throw new Error("Cancelled.");return s;}
function num(label,value,min,max){var s=ask(label,String(value)),n=Number(s);if(!s.replace(/\s/g,"")||!isFinite(n)||n<min||n>max)throw new Error("Invalid number: "+label);return n;}
function active(){var c=app.project.activeItem;if(!(c instanceof CompItem))throw new Error("Open a composition first.");return c;}
function selected(c){var a=c.selectedLayers;if(!a.length)throw new Error("Select layers first.");for(var i=0;i<a.length;i++)if(a[i].locked)throw new Error("Unlock selected layers first.");return a;}
function opacity(l){return l.property("ADBE Transform Group").property("ADBE Opacity");}
function textProp(l){var p=l.property("ADBE Text Properties");return p?p.property("ADBE Text Document"):null;}
function plainText(p){if(p.numKeys||p.expressionEnabled)throw new Error("Animated or expression-driven Source Text is not supported.");}
function readRows(){var f=File.openDialog("Choose UTF-8 TSV");if(!f)throw new Error("Cancelled.");f.encoding="UTF-8";if(!f.open("r"))throw new Error("Cannot open TSV.");var s;try{s=f.read();}finally{f.close();}var lines=s.replace(/^\uFEFF/,"").replace(/\r\n?/g,"\n").split("\n"),r=[];for(var i=1;i<lines.length;i++)if(lines[i].replace(/\s/g,""))r.push(lines[i].split("\t"));return r;}
function showReport(title,body){var w=new Window("dialog",title);w.orientation="column";w.alignChildren=["fill","fill"];var box=w.add("edittext",undefined,body,{multiline:true,scrolling:true});box.preferredSize=[680,420];w.add("button",undefined,"Close",{name:"ok"});w.show();}

var begun=false;try{if(!app.project)throw new Error("Open a project first.");app.beginUndoGroup("16_Replace_Selected_Text");begun=true;
var c=active(),a=selected(c),find=ask("Literal text to find (case-sensitive)","Guest Name"),replacement=ask("Replacement text","Alex Example"),changes=[];if(!find)throw new Error("Find text cannot be empty.");for(var i=0;i<a.length;i++){var p=textProp(a[i]);if(p){plainText(p);var d=p.value;if(d.text.indexOf(find)!==-1)changes.push({p:p,d:d,value:d.text.split(find).join(replacement)});}}for(var j=0;j<changes.length;j++){var change=changes[j];change.d.text=change.value;change.p.setValue(change.d);}alert("Updated "+changes.length+" text layers. Review mixed text formatting; it may normalize when Source Text is rewritten.");
}catch(e){alert("16_Replace_Selected_Text\n"+e.toString()+"\nUse Edit > Undo if changes were made.");}finally{if(begun)app.endUndoGroup();}
}());
