'use strict';const assert=require('assert'),fs=require('fs'),{analyzeWav,planCuts,toTSV,toXML,rate}=require('./planner');
let passed=0;function test(name,fn){fn();passed++;console.log('PASS '+name);}
function env(duration,fn){const step=.05;return {duration,step,levels:Array.from({length:Math.ceil(duration/step)},(_,i)=>fn(i*step))};}
function wav(bits=16,code=1,channels=1,duration=.2){const sr=8000,n=Math.round(sr*duration),bytes=bits/8,b=new ArrayBuffer(44+n*channels*bytes),v=new DataView(b);const put=(p,s)=>[...s].forEach((c,i)=>v.setUint8(p+i,c.charCodeAt(0)));put(0,'RIFF');v.setUint32(4,b.byteLength-8,true);put(8,'WAVE');put(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,code,true);v.setUint16(22,channels,true);v.setUint32(24,sr,true);v.setUint32(28,sr*channels*bytes,true);v.setUint16(32,channels*bytes,true);v.setUint16(34,bits,true);put(36,'data');v.setUint32(40,n*channels*bytes,true);for(let i=0;i<n;i++)for(let ch=0;ch<channels;ch++){const a=.25*Math.sin(2*Math.PI*440*i/sr),p=44+(i*channels+ch)*bytes;if(code===3)v.setFloat32(p,a,true);else if(bits===16)v.setInt16(p,a*32767,true);else if(bits===32)v.setInt32(p,a*2147483647,true);else{let k=Math.round(a*8388607);v.setUint8(p,k&255);v.setUint8(p+1,(k>>8)&255);v.setUint8(p+2,(k>>16)&255);}}return b;}
for(const [bits,code] of [[16,1],[24,1],[32,1],[32,3]])test('WAV '+bits+' code '+code,()=>{const a=analyzeWav(wav(bits,code));assert(Math.abs(a.duration-.2)<1e-6);assert(a.levels.every(n=>n>-17&&n<-13));});
test('Stereo PCM',()=>assert.equal(analyzeWav(wav(16,1,2)).channels,2));
test('Malformed WAV rejects',()=>assert.throws(()=>analyzeWav(new ArrayBuffer(44))));
test('Truncated chunk rejects',()=>{const b=wav();assert.throws(()=>analyzeWav(b.slice(0,100)))});
const a=env(20,t=>t<10?-15:-70),b=env(20,t=>t>=10?-15:-70);
test('Sustained speaker change',()=>{const p=planCuts([a,b],{fps:30,minShot:2,confirm:.5});assert.equal(p.shots.length,2);assert.equal(p.shots[0].camera,0);assert.equal(p.shots[1].camera,1);assert(p.shots[1].startFrame>=300&&p.shots[1].startFrame<=317)});
test('Brief interjection ignored',()=>{const p=planCuts([env(20,()=>-15),env(20,t=>t>5&&t<5.2?-5:-70)],{confirm:.5});assert.equal(p.shots.length,1)});
test('Overlap selects wide',()=>{const p=planCuts([env(20,()=>-15),env(20,t=>t>8&&t<15?-15:-70)],{wide:2});assert(p.shots.some(s=>s.camera===2))});
test('Silence holds current',()=>{const p=planCuts([env(12,()=>-90),env(12,()=>-90)],{});assert.equal(p.shots.length,1);assert.equal(p.silenceSeconds,12)});
test('Mismatched duration rejects',()=>assert.throws(()=>planCuts([a,env(21,()=>-20)],{})));
test('Negative settings reject',()=>assert.throws(()=>planCuts([a,b],{minShot:-1})));
test('Output covers all frames with contiguous positive shots',()=>{const p=planCuts([a,b],{fps:29.97});let last=0;for(const s of p.shots){assert.equal(s.startFrame,last);assert(s.endFrame>s.startFrame);last=s.endFrame;}assert.equal(last,p.frames);assert.equal(p.timebase,30);assert.equal(p.ntsc,true)});
test('TSV camera mapping',()=>{const p=planCuts([a,b],{});const t=toTSV(p,['Host','Guest']);assert(t.includes('\tHost\t'));assert(t.includes('\tGuest\t'));assert.throws(()=>toTSV(p,['Bad\tName','Guest']))});
test('XML escaping and URL encoding',()=>{const p=planCuts([a,b],{});const xml=toXML(p,[{name:'Host & Camera',path:'/Users/test/host movie.mov'},{name:'Guest',path:'/Users/test/guest.mov'}],{masterPath:'/Users/test/master.wav',masterChannels:2});assert(xml.includes('Host &amp; Camera'));assert(xml.includes('host%20movie.mov'));assert(xml.includes('<audio>'));fs.writeFileSync(__dirname+'/test-cut.xml',xml)});
test('Relative media paths rejected',()=>assert.throws(()=>toXML(planCuts([a,b],{}),[{name:'A',path:'relative.mov'},{name:'B',path:'b.mov'}],{})));
console.log(passed+' multicam tests passed; Adobe host validation pending.');
