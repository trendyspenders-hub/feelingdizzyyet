const {spawnSync}=require('child_process'),path=require('path');
for(const file of ['shared/test.js','Premiere/tests/core.test.js','tests/ae-utilities.test.js','tests/audio.test.js','tests/premiere-multicam.test.js','tests/ae-multicam.test.js','tests/audit-regressions.test.js']){const r=spawnSync(process.execPath,[path.join(__dirname,file)],{stdio:'inherit'});if(r.status!==0)process.exit(r.status||1)}
console.log('77 behavior checks passed. Native Adobe/OS tests remain pending.');
