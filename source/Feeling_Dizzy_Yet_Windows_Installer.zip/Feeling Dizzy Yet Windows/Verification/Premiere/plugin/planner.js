/* Feeling Dizzy Yet / Multicam Studio 0.1.0 | MIT | Local audio-based first cuts */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.FDYMulticam=factory();}(this,function(){
'use strict';
function fail(s){throw new Error(s);}
function rate(v){var n=Number(v),pairs=[[23.976,24000/1001],[29.97,30000/1001],[59.94,60000/1001]];for(var i=0;i<pairs.length;i++)if(Math.abs(n-pairs[i][0])<.001)return {fps:pairs[i][1],timebase:Math.round(n),ntsc:true};if([24,25,30,50,60].indexOf(n)<0)fail('Choose supported output FPS.');return {fps:n,timebase:n,ntsc:false};}
function analyzeWav(buffer,step){
 step=step||.05;var v=new DataView(buffer),length=v.byteLength;
 function str(p,n){var s='';for(var i=0;i<n;i++)s+=String.fromCharCode(v.getUint8(p+i));return s;}
 if(length<44||str(0,4)!=='RIFF'||str(8,4)!=='WAVE')fail('Use uncompressed little-endian RIFF WAV audio.');
 var format=null,data=null,p=12;
 while(p+8<=length){var name=str(p,4),size=v.getUint32(p+4,true),start=p+8;if(start+size>length)fail('Truncated WAV chunk.');
 if(name==='fmt '){if(size<16)fail('Invalid WAV format chunk.');format={code:v.getUint16(start,true),channels:v.getUint16(start+2,true),sampleRate:v.getUint32(start+4,true),block:v.getUint16(start+12,true),bits:v.getUint16(start+14,true)};}
 if(name==='data'&&!data)data={start:start,size:size};p=start+size+(size%2);
 }
 if(!format||!data)fail('Missing WAV format or audio data.');var f=format,bytes=f.bits/8;
 if((f.code!==1&&f.code!==3)||(f.code===1&&[16,24,32].indexOf(f.bits)<0)||(f.code===3&&f.bits!==32)||f.channels<1||f.channels>2||f.sampleRate<8000||f.sampleRate>192000||f.block!==bytes*f.channels)fail('Supported WAV: PCM 16/24/32-bit or float32, mono/stereo, 8–192 kHz. WAV extensible/compressed formats are not supported.');
 var samples=Math.floor(data.size/f.block),duration=samples/f.sampleRate;if(!samples||duration>7200)fail('Audio must be non-empty and at most two hours.');
 function sample(offset){if(f.code===3){var z=v.getFloat32(offset,true);return isFinite(z)?z:0;}if(f.bits===16)return v.getInt16(offset,true)/32768;if(f.bits===32)return v.getInt32(offset,true)/2147483648;var n=v.getUint8(offset)|(v.getUint8(offset+1)<<8)|(v.getUint8(offset+2)<<16);if(n&0x800000)n-=0x1000000;return n/8388608;}
 var envelope=[],window=Math.max(1,Math.round(step*f.sampleRate)),stride=Math.max(1,Math.floor(f.sampleRate/8000));
 for(var s=0;s<samples;s+=window){var total=0,count=0,last=Math.min(samples,s+window);for(var j=s;j<last;j+=stride){var max=0;for(var ch=0;ch<f.channels;ch++){var a=sample(data.start+j*f.block+ch*bytes);max=Math.max(max,a*a);}total+=max;count++;}envelope.push(10*Math.log(Math.max(total/Math.max(count,1),1e-12))/Math.LN10);}
 return {duration:duration,step:window/f.sampleRate,levels:envelope,sampleRate:f.sampleRate,channels:f.channels,bits:f.bits};
}
function planCuts(analyses,options){
 options=options||{};if(!analyses||analyses.length<2||analyses.length>8)fail('Use 2–8 isolated microphone files.');var r=rate(options.fps||30),fps=r.fps,duration=analyses[0].duration;
 for(var i=0;i<analyses.length;i++)if(Math.abs(analyses[i].duration-duration)>.1)fail('Microphone WAV durations differ by more than 0.1 seconds. Export synchronized tracks with equal start and end.');
 var min=Number(options.minShot===undefined?2.5:options.minShot),confirm=Number(options.confirm===undefined ? .5:options.confirm),floor=Number(options.floor===undefined?-40:options.floor),dominance=Number(options.dominance===undefined?6:options.dominance),wide=options.wide===undefined?null:options.wide;
 if(!isFinite(min)||min<.25||min>60||!isFinite(confirm)||confirm<0||confirm>10||!isFinite(floor)||floor< -100||floor>0||!isFinite(dominance)||dominance<0||dominance>40)fail('Invalid cut settings.');if(wide!==null&&wide!==analyses.length)fail('Wide camera must be the final, extra camera.');
 var frames=Math.floor(duration*fps+1e-8);if(frames<1)fail('Audio is shorter than one output frame.');var current=0,start=0,pending=-1,pendingStart=0,lastCut=0,shots=[],overlap=0,silence=0;
 for(var frame=0;frame<frames;frame++){
 var t=frame/fps,scores=[];for(var mic=0;mic<analyses.length;mic++){var a=analyses[mic];scores.push({camera:mic,db:a.levels[Math.min(a.levels.length-1,Math.floor(t/a.step))]});}scores.sort(function(a,b){return b.db-a.db;});
 var candidate=current;
 if(scores[0].db<floor){silence++;candidate=current;}
 else if(scores[1].db>=floor&&scores[0].db-scores[1].db<dominance){overlap++;candidate=wide===null?current:wide;}
 else candidate=scores[0].camera;
 if(frame===0){current=candidate;pending=candidate;pendingStart=0;continue;}
 if(candidate!==pending){pending=candidate;pendingStart=frame;}
 if(candidate!==current&&(frame-lastCut)/fps>=min&&(frame-pendingStart)/fps>=confirm){shots.push({startFrame:start,endFrame:frame,camera:current});start=frame;lastCut=frame;current=candidate;}
 }
 shots.push({startFrame:start,endFrame:frames,camera:current});
 if(shots.length>1&&(shots[shots.length-1].endFrame-shots[shots.length-1].startFrame)/fps<min){var tail=shots.pop();shots[shots.length-1].endFrame=tail.endFrame;}
 if(shots.length>5000)fail('Cut count exceeds 5,000. Increase minimum shot length.');
 return {fps:fps,timebase:r.timebase,ntsc:r.ntsc,duration:frames/fps,frames:frames,shots:shots,overlapSeconds:overlap/fps,silenceSeconds:silence/fps,microphones:analyses.length,settings:{minShot:min,confirm:confirm,floor:floor,dominance:dominance,wide:wide}};
}
function toTSV(plan,cameras){var rows=['start_frame\tend_frame\tcamera\tfps'];for(var i=0;i<plan.shots.length;i++){var s=plan.shots[i],name=cameras[s.camera];if(!name||/[\t\r\n]/.test(name))fail('Camera names must be non-empty without tabs/newlines.');rows.push([s.startFrame,s.endFrame,name,plan.fps].join('\t'));}return rows.join('\n')+'\n';}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');}
function fileURL(path){if(!/^\//.test(path)&&!(/^[A-Za-z]:[\\/]/.test(path)))fail('Enter full absolute media paths for XML export.');var p=String(path).replace(/\\/g,'/');return 'file://localhost'+(p.charAt(0)==='/'?'':'/')+p.split('/').map(function(x){return encodeURIComponent(x);}).join('/');}
function toXML(plan,cameras,options){
 options=options||{};var width=Number(options.width===undefined?1920:options.width),height=Number(options.height===undefined?1080:options.height);if(!isFinite(width)||!isFinite(height)||width%1||height%1||width<16||height<16||width>16384||height>16384)fail('Invalid output dimensions.');
 function r(){return '<rate><timebase>'+plan.timebase+'</timebase><ntsc>'+(plan.ntsc?'TRUE':'FALSE')+'</ntsc></rate>';}
 function file(cam,id,video){var p=fileURL(cam.path);return '<file id="'+id+'"><name>'+esc(cam.name)+'</name><pathurl>'+esc(p)+'</pathurl>'+r()+'<duration>'+plan.frames+'</duration><media>'+(video?'<video><samplecharacteristics>'+r()+'<width>'+width+'</width><height>'+height+'</height><anamorphic>FALSE</anamorphic><pixelaspectratio>square</pixelaspectratio><fielddominance>none</fielddominance></samplecharacteristics></video>':'<audio><samplecharacteristics><depth>'+Number(options.masterBits||16)+'</depth><samplerate>'+Number(options.masterRate||48000)+'</samplerate></samplecharacteristics><channelcount>'+Number(options.masterChannels||2)+'</channelcount></audio>')+'</media></file>';}
 var video='',used={};for(var i=0;i<plan.shots.length;i++){var s=plan.shots[i],cam=cameras[s.camera];if(!cam)fail('Missing camera mapping.');var id='camera-'+s.camera;video+='<clipitem id="shot-'+i+'"><name>'+esc(cam.name)+'</name><enabled>TRUE</enabled>'+r()+'<start>'+s.startFrame+'</start><end>'+s.endFrame+'</end><in>'+s.startFrame+'</in><out>'+s.endFrame+'</out>'+(used[id]?'<file id="'+id+'"/>':file(cam,id,true))+'<sourcetrack><mediatype>video</mediatype><trackindex>1</trackindex></sourcetrack></clipitem>';used[id]=true;}
 var audio='';if(options.masterPath){var channels=Number(options.masterChannels||2);if(channels!==1&&channels!==2)fail('Master audio channels must be mono or stereo.');for(var ch=1;ch<=channels;ch++)audio+='<track><clipitem id="master-'+ch+'"><name>Master audio</name><enabled>TRUE</enabled>'+r()+'<start>0</start><end>'+plan.frames+'</end><in>0</in><out>'+plan.frames+'</out>'+(ch===1?file({path:options.masterPath,name:'Master audio'},'master-file',false):'<file id="master-file"/>')+'<sourcetrack><mediatype>audio</mediatype><trackindex>'+ch+'</trackindex></sourcetrack></clipitem></track>';}
 return '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="4"><sequence id="feeling-dizzy-yet-first-cut"><name>'+esc(options.name||'Feeling Dizzy Yet - First Cut')+'</name><duration>'+plan.frames+'</duration>'+r()+'<media><video><format><samplecharacteristics>'+r()+'<width>'+width+'</width><height>'+height+'</height><anamorphic>FALSE</anamorphic><pixelaspectratio>square</pixelaspectratio><fielddominance>none</fielddominance></samplecharacteristics></format><track>'+video+'</track></video><audio><numOutputChannels>'+Number(options.masterChannels||2)+'</numOutputChannels>'+audio+'</audio></media></sequence></xmeml>';
}
return {analyzeWav:analyzeWav,planCuts:planCuts,toTSV:toTSV,toXML:toXML,rate:rate};
}));
