/* Feeling Dizzy Yet / Premiere Edition 0.1.0
 * Host adapter. Core host calls documented by Adobe as available since 25.6.
 * No Adobe execution certification implied. MIT source.
 */
'use strict';
function atLeast(value, minimum='25.6.0') {
 const a=String(value||'').split('.').map(Number), b=minimum.split('.').map(Number);
 for(let i=0;i<3;i++){const x=Number.isFinite(a[i])?a[i]:0,y=b[i]||0;if(x!==y)return x>y;}return true;
}
function required(obj,name){if(!obj||typeof obj[name]!=='function')throw new Error('Unavailable host API: '+name+'. Check Premiere version and the compatibility report.');return obj[name].bind(obj);}
function clean(value,label='Text',empty=false){const s=String(value==null?'':value);if((!empty&&!s.trim())||s.length>10000)throw new Error(label+' is empty or too long.');return s;}
function numeric(value,label,min,max){if(String(value).trim()==='')throw new Error(label+' is required.');const n=Number(value);if(!Number.isFinite(n)||n<min||n>max)throw new Error(label+' must be between '+min+' and '+max+'.');return n;}
function integer(value,label,min,max){const n=numeric(value,label,min,max);if(!Number.isInteger(n))throw new Error(label+' must be a whole number.');return n;}
function parseMarkers(text,end){
 const lines=String(text).replace(/^\uFEFF/,'').replace(/\r\n?/g,'\n').split('\n');
 const header=(lines.shift()||'').split('\t');
 if(header.join('\t')!=='start_seconds\tduration_seconds\tname\tcomments')throw new Error('Use header: start_seconds<TAB>duration_seconds<TAB>name<TAB>comments.');
 const seen=new Set(),rows=[];
 lines.forEach((line,index)=>{if(!line.trim())return;const r=line.split('\t');if(r.length!==4)throw new Error('TSV data row '+(index+1)+' needs 4 columns.');
 const start=numeric(r[0],'Marker start',0,end),duration=numeric(r[1],'Marker duration',0,end);if(start>=end||start+duration>end+1e-9)throw new Error('Marker lies outside sequence.');const key=String(start);if(seen.has(key))throw new Error('Duplicate marker start time.');seen.add(key);rows.push({start,duration,name:clean(r[2],'Marker name'),comments:r[3]});});
 if(!rows.length||rows.length>1000)throw new Error('Use 1–1000 marker rows.');return rows;
}
function tsvCell(v){return String(v==null?'':v).replace(/[\t\r\n]/g,' ');}
function createEngine(ppro,host){
 function versionCheck(){if(!atLeast(host.version))throw new Error('Premiere 25.6 or later is required. Detected: '+host.version);}
 async function project(){versionCheck();const p=await required(ppro.Project,'getActiveProject')();if(!p)throw new Error('Open a Premiere project first.');return p;}
 async function sequence(p){const s=await required(p,'getActiveSequence')();if(!s)throw new Error('Open a sequence first.');return s;}
 const key=p=>String(p.guid)+'|'+String(p.path||'');
 async function guard(p,s){const now=await project();if(key(now)!==key(p))throw new Error('Active project changed. Prepare the tool again.');if(s){const current=await sequence(now);if(String(current.guid)!==String(s.guid))throw new Error('Active sequence changed. Prepare the tool again.');}}
 function time(n){return required(ppro.TickTime,'createWithSeconds')(n);}
 async function selection(p){const selected=await required(ppro.ProjectUtils,'getSelection')(p);const a=await required(selected,'getItems')();if(!a.length)throw new Error('Select items in the Project panel first.');return a;}
 async function timeline(s){const a=await required(await required(s,'getSelection')(),'getTrackItems')();if(!a.length)throw new Error('Select timeline clips first.');return a;}
 async function commit(p,label,builders){
  required(p,'lockedAccess');required(p,'executeTransaction');let ok=false,called=false;
  p.lockedAccess(()=>{called=true;const actions=builders.map(build=>build());if(!actions.length){ok=true;return;}ok=p.executeTransaction(compound=>{for(const action of actions){if(!action)throw new Error('Host returned an empty action.');const result=compound.addAction(action);if(result===false)throw new Error('Host refused an action.');}},'Feeling Dizzy Yet: '+label);});
  if(!called||ok!==true)throw new Error('Premiere did not confirm the transaction. Inspect project and Undo history.');
 }
 function plan(p,s,summary,apply){let used=false;return {summary,async apply(){if(used)throw new Error('This preview has already been applied. Prepare again.');await guard(p,s);used=true;return apply();}};}
 async function walk(p){const root=await required(p,'getRootItem')(),out=[],seen=new Set();async function visit(folder,level){const children=await required(folder,'getItems')();for(const x of children){out.push({item:x,level});if(out.length>10000)throw new Error('Project scan capped at 10,000 items.');let f=null;try{f=ppro.FolderItem.cast(x);}catch(ignore){}if(f){const id=required(x,'getId')();if(!seen.has(id)){seen.add(id);await visit(f,level+1);}}}}await visit(root,0);return out;}
 function asClip(x){let c=null;try{c=required(ppro.ClipProjectItem,'cast')(x);}catch(ignore){}if(!c)throw new Error('Select media clips, not bins: '+x.name);return c;}
 async function markers(s){const m=await required(ppro.Markers,'getMarkers')(s);const list=await required(m,'getMarkers')([]);return {m,list};}
 async function snapshotMarkers(s){const {list}=await markers(s);return list.map(m=>[m.getStart().seconds,m.getDuration().seconds,m.getName(),m.getComments()]);}
 async function markPlan(p,s,rows,label){const before=await snapshotMarkers(s),existing=before.map(m=>m[0]);const ticks=rows.map(r=>time(r.start).ticks);if(new Set(ticks).size!==ticks.length)throw new Error('Two marker times resolve to the same host tick.');for(const row of rows)if(existing.some(t=>Math.abs(t-row.start)<1e-8))throw new Error('A marker already exists at '+row.start+' seconds.');const signature=JSON.stringify(before);
  return plan(p,s,'Add '+rows.length+' comment marker(s) to '+s.name+'. Times are seconds, not display timecode.\n'+rows.map(r=>r.start+'s | '+r.name).join('\n'),async()=>{if(JSON.stringify(await snapshotMarkers(s))!==signature)throw new Error('Markers changed after preview. Prepare again.');const {m}=await markers(s);await commit(p,label,rows.map(r=>()=>required(m,'createAddMarkerAction')(r.name,'Comment',time(r.start),time(r.duration),r.comments)));return 'Added '+rows.length+' markers. Verify placement and use Undo to revert.';});}
 async function tracks(s){const out=[];for(const kind of ['Video','Audio']){const count=await required(s,'get'+kind+'TrackCount')();for(let i=0;i<count;i++){const tr=await required(s,'get'+kind+'Track')(i);out.push({kind,index:i,track:tr});}}return out;}
 async function clipRows(s){const rows=[];for(const x of await tracks(s)){const clips=await required(x.track,'getTrackItems')(1,false);for(const clip of clips)rows.push({kind:x.kind,index:x.index,clip,start:(await clip.getStartTime()).seconds,end:(await clip.getEndTime()).seconds,name:await clip.getName()});}return rows;}
 async function prepare(id,args={}){
 versionCheck();
 if(id==='diagnostics')return {report:JSON.stringify({product:'Feeling Dizzy Yet — Premiere Edition',version:'0.1.0',host:host.name,hostVersion:host.version,minVersion:'25.6.0',apiAvailable:{Project:!!ppro.Project,Markers:!!ppro.Markers,TickTime:!!ppro.TickTime,FolderItem:!!ppro.FolderItem,ProjectUtils:!!ppro.ProjectUtils},status:'Development preview. Adobe execution testing pending.'},null,2)};
 const p=await project();
 if(id==='project')return {report:JSON.stringify({name:p.name,path:p.path,guid:String(p.guid),sequences:(await p.getSequences()).map(s=>s.name)},null,2)};
 if(id==='sequences'){const out=[];for(const s of await p.getSequences())out.push(s.name+' | '+(await s.getEndTime()).seconds+' seconds');return {report:out.join('\n')||'No sequences.'};}
 if(id==='tree'){const all=await walk(p);return {report:all.map(x=>'  '.repeat(x.level)+x.item.name).join('\n')||'Empty project.'};}
 if(id==='offline'||id==='proxies'||id==='multicam'){
  const all=await walk(p),out=[];let checked=0;
  for(const {item} of all){let c;try{c=asClip(item);}catch(ignore){continue;}checked++;
   if(id==='offline'&&await required(c,'isOffline')())out.push(item.name+' | '+await c.getMediaFilePath());
   if(id==='proxies')out.push(item.name+' | proxy='+await c.hasProxy()+' | '+await c.getProxyPath());
   if(id==='multicam'&&await c.isMulticamClip())out.push(item.name+' | multicam source detected');
  }return {report:'Checked '+checked+' clip items.\n'+(out.join('\n')||'No matching items.')+(id==='multicam'?'\nDetection only. No syncing, speaker analysis or automatic angle cutting.':'')};
 }
 if(id==='bins'){
  const root=await p.getRootItem(),children=await root.getItems(),names=['01 Cameras','02 Microphones','03 Graphics','04 Sequences','05 Review','06 Deliverables'];const missing=[];
  for(const n of names){const match=children.filter(x=>x.name===n);if(match.length){let f;try{f=ppro.FolderItem.cast(match[0]);}catch(ignore){}if(match.length!==1||!f)throw new Error('Ambiguous or non-bin item named '+n);}else missing.push(n);}
  return plan(p,null,'Create '+missing.length+' root bins. Existing unique bins reused.\n'+missing.join('\n'),async()=>{const now=await root.getItems();if(missing.some(n=>now.some(x=>x.name===n)))throw new Error('Project bins changed. Prepare again.');await commit(p,'Create podcast bins',missing.map(n=>()=>root.createBinAction(n,false)));return 'Created '+missing.length+' bins.';});
 }
 if(['prefix','replace','labels','selection'].includes(id)){
  const a=await selection(p);if(id==='selection')return {report:a.map(x=>x.name+' | ID '+x.getId()).join('\n')};
  let updates=[];
  if(id==='prefix'){const prefix=clean(args.prefix,'Prefix');updates=a.map(x=>({x,old:x.name,name:prefix+x.name}));}
  if(id==='replace'){const find=clean(args.find,'Find'),replacement=clean(args.replacement,'Replacement',true);updates=a.filter(x=>x.name.includes(find)).map(x=>({x,old:x.name,name:x.name.split(find).join(replacement)}));}
  const label=id==='labels'?integer(args.label,'Label index',0,15):null;
  if(id==='labels')updates=a.map(x=>({x,old:x.name}));
  updates.forEach(q=>required(q.x,id==='labels'?'createSetColorLabelAction':'createSetNameAction'));
  return plan(p,null,(id==='labels'?'Set label '+label:'Rename')+' on '+updates.length+' Project items. Disk file names unchanged.\n'+updates.map(q=>q.old+(q.name?' -> '+q.name:'')).join('\n'),async()=>{if(updates.some(q=>q.x.name!==q.old))throw new Error('Target names changed. Prepare again.');await commit(p,id,updates.map(q=>()=>id==='labels'?q.x.createSetColorLabelAction(label):q.x.createSetNameAction(q.name)));return 'Updated '+updates.length+' project items.';});
 }
 if(id==='importXML'){
  const path=clean(args.path,'XML path');if(!/\.xml$/i.test(path))throw new Error('Choose an XML file from Multicam Studio.');
  const root=await p.getRootItem();return plan(p,null,'Import XML edit into '+p.name+' from:\n'+path+'\nThis may create new bins, media and a sequence. Review relinking and audio.',async()=>{const ok=await required(p,'importFiles')([path],false,root,false);if(ok!==true)throw new Error('Premiere did not confirm XML import. Inspect import dialogs and project.');return 'XML import confirmed by host. Check the new sequence and all media links.';});
 }
 const s=await sequence(p);
 if(id==='sequence')return {report:JSON.stringify({name:s.name,guid:String(s.guid),endSeconds:(await s.getEndTime()).seconds,inSeconds:(await s.getInPoint()).seconds,outSeconds:(await s.getOutPoint()).seconds,playheadSeconds:(await s.getPlayerPosition()).seconds,ticksPerFrame:await s.getTimebase(),videoTracks:await s.getVideoTrackCount(),audioTracks:await s.getAudioTrackCount(),captionTracks:await s.getCaptionTrackCount()},null,2)};
 if(id==='tracks'){const rows=[];for(const x of await tracks(s))rows.push(x.kind+' '+(x.index+1)+' | '+x.track.name+' | muted='+await x.track.isMuted()+' | clips='+(await x.track.getTrackItems(1,false)).length);return {report:rows.join('\n')};}
 if(id==='clone')return plan(p,s,'Clone active sequence: '+s.name+'. The clone uses Premiere naming and shares source media. No custom clone name is promised.',async()=>{await commit(p,'Clone sequence',[()=>required(s,'createCloneAction')()]);return 'Sequence clone requested successfully. Check Project panel.';});
 if(id==='renameSequence'){const name=clean(args.name,'Sequence name'),item=await s.getProjectItem();return plan(p,s,'Rename active sequence '+s.name+' -> '+name,async()=>{await commit(p,'Rename sequence',[()=>required(item,'createSetNameAction')(name)]);return 'Sequence renamed.';});}
 if(id==='marker'){
  const start=(await s.getPlayerPosition()).seconds,end=(await s.getEndTime()).seconds,duration=numeric(args.duration,'Duration',0,end);if(start>=end||start+duration>end)throw new Error('Marker exceeds sequence end.');return markPlan(p,s,[{start,duration,name:clean(args.name,'Marker name'),comments:String(args.comments||'')}],'Add marker');
 }
 if(id==='importMarkers')return markPlan(p,s,parseMarkers(args.tsv,(await s.getEndTime()).seconds),'Import markers');
 if(id==='markers'){const rows=await snapshotMarkers(s);return {report:['start_seconds\tduration_seconds\tname\tcomments',...rows.map(r=>r.map(tsvCell).join('\t'))].join('\n'),extension:'tsv'};}
 if(id==='markerSearch'){const query=clean(args.query,'Search text').toLowerCase();const rows=(await snapshotMarkers(s)).filter(r=>(r[2]+' '+r[3]).toLowerCase().includes(query));return {report:rows.map(r=>r[0]+'s | '+r[2]+' | '+r[3]).join('\n')||'No matching markers.'};}
 if(id==='range'){const end=(await s.getEndTime()).seconds,start=numeric(args.start,'In point',0,end),out=numeric(args.end,'Out point',0,end);if(out<=start)throw new Error('Out point must follow in point.');return plan(p,s,'Set sequence In/Out to '+start+'–'+out+' seconds. Clips are not trimmed.',async()=>{await commit(p,'Set sequence range',[()=>required(s,'createSetInPointAction')(time(start)),()=>required(s,'createSetOutPointAction')(time(out))]);return 'In/Out updated. Check source monitor range.';});}
 if(id==='jump'){const target=numeric(args.seconds,'Seconds',0,(await s.getEndTime()).seconds);return plan(p,s,'Move playhead to '+target+' seconds. This navigation may not be undoable.',async()=>{if(await s.setPlayerPosition(time(target))!==true)throw new Error('Playhead navigation failed.');return 'Playhead moved.';});}
 if(id==='timeline'||id==='renameClips'||id==='disable'||id==='enable'){
  const a=await timeline(s);if(id==='timeline'){const out=[];for(const clip of a)out.push(await clip.getName()+' | '+(await clip.getStartTime()).seconds+'–'+(await clip.getEndTime()).seconds+'s');return {report:out.join('\n')};}
  const prefix=id==='renameClips'?clean(args.prefix,'Clip prefix'):null;const names=[];for(const clip of a){required(clip,id==='renameClips'?'createSetNameAction':'createSetDisabledAction');names.push(await clip.getName());}
  return plan(p,s,(id==='renameClips'?'Prefix names of':id==='disable'?'Disable':'Enable')+' '+a.length+' selected timeline items. Linked audio/video follows actual selection; do not assume both are selected.\n'+names.join('\n'),async()=>{await commit(p,id,a.map((clip,i)=>()=>id==='renameClips'?clip.createSetNameAction(prefix+names[i]):clip.createSetDisabledAction(id==='disable')));return 'Updated '+a.length+' timeline items.';});
 }
 if(id==='gaps'){const all=await clipRows(s),out=['Per-video-track gaps only; other tracks may cover them. Transitions/effects are not analyzed.'];for(const t of await tracks(s)){if(t.kind!=='Video')continue;let cursor=0;for(const clip of all.filter(x=>x.kind==='Video'&&x.index===t.index).sort((a,b)=>a.start-b.start)){if(clip.start-cursor>0.000001)out.push('V'+(t.index+1)+' | '+cursor+'–'+clip.start+'s');cursor=Math.max(cursor,clip.end);}}return {report:out.join('\n')};}
 throw new Error('Unknown tool: '+id);
 }
 return {prepare};
}
module.exports={createEngine,atLeast,parseMarkers,numeric,integer,tsvCell};
