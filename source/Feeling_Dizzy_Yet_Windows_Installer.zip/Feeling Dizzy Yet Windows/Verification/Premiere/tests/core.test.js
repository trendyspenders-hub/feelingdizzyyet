'use strict';const assert=require('assert');const {createEngine,atLeast,parseMarkers}=require('../plugin/core');
function mock(){let committed=0,actionsMade=0,locked=false,tx=false;const state={active:null};
 const markers=[];const markerAPI={getMarkers:()=>markers,createAddMarkerAction(name,type,start,duration,comments){assert(locked&&!tx);actionsMade++;return ()=>markers.push({getStart:()=>start,getDuration:()=>duration,getName:()=>name,getComments:()=>comments})}};
 const items=[{name:'Draft A',getId:()=>1,createSetNameAction(name){assert(locked&&!tx);actionsMade++;return ()=>{this.name=name}},createSetColorLabelAction(index){assert(locked&&!tx);return ()=>{this.label=index}}}];
 const seq={guid:'seq1',name:'Episode',getEndTime:async()=>({seconds:20}),getPlayerPosition:async()=>({seconds:2}),getSelection:async()=>({getTrackItems:async()=>[]})};
 const p={guid:'project1',name:'Test',path:'/tmp/test.prproj',getActiveSequence:async()=>seq,getSequences:async()=>[seq],getRootItem:async()=>({getItems:async()=>items}),lockedAccess(fn){locked=true;try{fn()}finally{locked=false}},executeTransaction(fn){assert(locked);tx=true;const pending=[];try{fn({addAction(a){pending.push(a);return true}})}finally{tx=false}pending.forEach(a=>a());committed++;return true}};state.active=p;
 const api={Project:{getActiveProject:async()=>state.active},ProjectUtils:{getSelection:async()=>({getItems:async()=>items})},TickTime:{createWithSeconds:seconds=>({seconds,ticks:String(Math.round(seconds*254016000000))})},Markers:{getMarkers:async()=>markerAPI}};
 return {engine:createEngine(api,{name:'premierepro',version:'25.6.0'}),state,items,markers,p,seq,stats:()=>({committed,actionsMade})};
}
(async()=>{let n=0;async function test(name,fn){await fn();n++;console.log('PASS '+name)}
await test('Minimum version',()=>{assert(atLeast('25.6.0'));assert(atLeast('26.0'));assert(!atLeast('25.5.9'))});
await test('Invalid TSV atomic validation',()=>assert.throws(()=>parseMarkers('start_seconds\tduration_seconds\tname\tcomments\n0\t0\tOK\tA\n21\t0\tBad\tB',20)));
await test('Duplicate marker start rejects',()=>assert.throws(()=>parseMarkers('start_seconds\tduration_seconds\tname\tcomments\n1\t0\tA\t\n1\t0\tB\t',20)));
await test('Read-only project report',async()=>{const m=mock();const r=await m.engine.prepare('project');assert(r.report.includes('Test'));assert.equal(m.stats().committed,0)});
await test('Preview does not mutate',async()=>{const m=mock();await m.engine.prepare('prefix',{prefix:'EP - '});assert.equal(m.items[0].name,'Draft A');assert.equal(m.stats().actionsMade,0)});
await test('Actions constructed under lock before transaction',async()=>{const m=mock();const p=await m.engine.prepare('prefix',{prefix:'EP - '});await p.apply();assert.equal(m.items[0].name,'EP - Draft A');assert.equal(m.stats().committed,1)});
await test('Preview can only apply once',async()=>{const m=mock();const p=await m.engine.prepare('prefix',{prefix:'X'});await p.apply();await assert.rejects(()=>p.apply())});
await test('Changed project blocks apply',async()=>{const m=mock();const p=await m.engine.prepare('prefix',{prefix:'X'});m.state.active={...m.p,guid:'another'};await assert.rejects(()=>p.apply());assert.equal(m.stats().committed,0)});
await test('Changed name blocks apply',async()=>{const m=mock();const p=await m.engine.prepare('prefix',{prefix:'X'});m.items[0].name='Changed';await assert.rejects(()=>p.apply())});
await test('Literal replace',async()=>{const m=mock();const p=await m.engine.prepare('replace',{find:'Draft',replacement:'Final'});await p.apply();assert.equal(m.items[0].name,'Final A')});
await test('Label bounds',async()=>{const m=mock();await assert.rejects(()=>m.engine.prepare('labels',{label:16}));assert.equal(m.stats().committed,0)});
await test('Marker import and report',async()=>{const m=mock();const p=await m.engine.prepare('importMarkers',{tsv:'start_seconds\tduration_seconds\tname\tcomments\n1\t0\tIntro\tOpening'});assert.equal(m.markers.length,0);await p.apply();assert.equal(m.markers.length,1);assert((await m.engine.prepare('markers')).report.includes('Intro'))});
await test('Marker collision blocks new preview',async()=>{const m=mock();const p=await m.engine.prepare('marker',{name:'A',duration:0});await p.apply();await assert.rejects(()=>m.engine.prepare('marker',{name:'B',duration:0}))});
await test('Empty timeline selection rejects',async()=>{const m=mock();await assert.rejects(()=>m.engine.prepare('disable'));assert.equal(m.stats().committed,0)});
await test('Bad sequence range rejects',async()=>{const m=mock();await assert.rejects(()=>m.engine.prepare('range',{start:10,end:2}))});
console.log(n+' adapter tests passed. Premiere runtime tests pending.');})().catch(e=>{console.error(e);process.exit(1)});
