Premiere 25.6 is the manifest minimum. Native execution on 25.6 and later releases remains pending. See AUDIT.md and INSTALLATION.md in the release root.
