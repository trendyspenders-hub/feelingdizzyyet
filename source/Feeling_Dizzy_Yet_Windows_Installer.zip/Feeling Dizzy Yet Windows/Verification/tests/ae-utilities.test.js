const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const root=path.join(__dirname,'../AfterEffects'),dir=path.join(root,'FeelingDizzyYet','scripts');
const files=fs.readdirSync(dir).filter(f=>f.endsWith('.jsx'));assert.equal(files.length,102);const ids=files.map(f=>parseInt(f,10)).sort((a,b)=>a-b);assert.deepEqual(ids,Array.from({length:102},(_,i)=>i+1));
for(const f of files)new vm.Script(fs.readFileSync(path.join(dir,f),'utf8'),{filename:f});new vm.Script(fs.readFileSync(path.join(root,'Feeling Dizzy Yet.jsx'),'utf8'));
function prop(v){return {value:v,numKeys:0,expressionEnabled:false,keys:[],writes:0,setValue(x){this.value=x;this.writes++},setValueAtTime(t,v){this.keys.push([t,v])}}}
function layer(index,extra={}){let p={'ADBE Position':prop([100*index,100]),'ADBE Anchor Point':prop([0,0]),'ADBE Scale':prop([100,100]),'ADBE Rotate Z':prop(0)},audio=prop([-3,-3]),text=prop({text:'Headline',fontSize:40});return Object.assign({index,name:'Layer '+index,inPoint:0,outPoint:5,startTime:0,locked:false,hasAudio:true,parent:null,threeDLayer:false,p,audio,text,property(n){if(n==='ADBE Transform Group')return {property(k){return p[k]}};if(n==='ADBE Audio Group')return {property(){return audio}};if(n==='ADBE Text Properties')return {property(){return text}}},sourceRectAtTime(){return {left:0,top:0,width:200,height:100}}},extra)}
function run(id,{ls=[],answers=[],input='',selection=[],markers=[]}={}){function CompItem(){}function FootageItem(){}function FolderItem(){}const c=new CompItem();Object.assign(c,{width:1920,height:1080,duration:10,time:0,frameRate:30,selectedLayers:ls,numLayers:ls.length,layer(i){return ls[i-1]},workAreaStart:1,workAreaDuration:4});const made=[];c.markerProperty={numKeys:markers.length,keyTime(i){return markers[i-1]},setValueAtTime(t,v){made.push([t,v])}};let b=0,e=0;const alerts=[];const ctx={CompItem,FootageItem,FolderItem,SolidSource:function(){},app:{project:{activeItem:c,selection},beginUndoGroup(){b++},endUndoGroup(){e++}},prompt(){return answers.length?answers.shift():null},alert(x){alerts.push(x)},confirm(){return true},MarkerValue:function(s){this.comment=s},File:{openDialog(){return {open(){return true},read(){return input},close(){}}}}};const f=files.find(f=>parseInt(f,10)===id);vm.runInNewContext(fs.readFileSync(path.join(dir,f),'utf8'),ctx);assert.equal(b,e);return {c,made,alerts};}
let n=0;function test(f){f();n++}
test(()=>{let x={name:'A'};run(42,{selection:[x],answers:['EP - ']});assert.equal(x.name,'EP - A')});
test(()=>{let x={name:'Draft Draft'};run(43,{selection:[x],answers:['Draft','Final']});assert.equal(x.name,'Final Final')});
test(()=>{let x={};run(44,{selection:[x],answers:['2.5']});assert.equal(x.label,undefined)});
test(()=>{let a=[layer(1),layer(2,{hasAudio:false})];run(56,{ls:a,answers:['-5']});assert.equal(a[0].audio.writes,0)});
test(()=>{let a=[layer(1),layer(2)];run(56,{ls:a,answers:['-5']});assert.equal(a[0].audio.value[0],-5)});
test(()=>{let a=[layer(1),layer(2)];a[1].audio.numKeys=1;run(57,{ls:a,answers:['.5']});assert.equal(a[0].audio.keys.length,0)});
test(()=>{let a=[layer(1)];run(57,{ls:a,answers:['.5']});assert.equal(a[0].audio.keys.length,4)});
test(()=>{let r=run(60,{input:'start\tduration\tlabel\n0\t2\tIntro\n3\t2\tTalk'});assert.equal(r.made.length,2)});
test(()=>{let r=run(60,{input:'start\tduration\tlabel\n0\t2\tIntro\n9\t2\tBad'});assert.equal(r.made.length,0)});
test(()=>{let r=run(60,{input:'start\tduration\tlabel\n0\t2\tIntro',markers:[0]});assert.equal(r.made.length,0)});
test(()=>{let a=[layer(1)];run(76,{ls:a});assert.equal(a[0].p['ADBE Position'].value[0],200);assert.equal(a[0].p['ADBE Position'].value[1],150)});
test(()=>{let a=[layer(1)];a[0].p['ADBE Rotate Z'].value=90;run(76,{ls:a});assert(Math.abs(a[0].p['ADBE Position'].value[0]-50)<1e-8);assert(Math.abs(a[0].p['ADBE Position'].value[1]-200)<1e-8)});
test(()=>{let a=[layer(1),layer(2,{parent:{}})];run(76,{ls:a});assert.equal(a[0].p['ADBE Position'].writes,0)});
test(()=>{let a=[layer(1)];run(77,{ls:a,answers:['CAFA6B']});assert.equal(a[0].text.value.fillColor[0],202/255)});
test(()=>{let a=[layer(1)];run(77,{ls:a,answers:['invalid']});assert.equal(a[0].text.writes,0)});
test(()=>{let a=[layer(1),layer(2,{inPoint:8,outPoint:10})];run(86,{ls:a});assert.equal(a[0].inPoint,0)});
test(()=>{let a=[layer(1)];run(86,{ls:a});assert.equal(a[0].inPoint,1);assert.equal(a[0].outPoint,5)});
test(()=>{let a=[layer(1),layer(2,{inPoint:0,outPoint:6})];run(87,{ls:a,answers:['0']});assert.equal(a[0].startTime,0);assert.equal(a[1].startTime,0)});
test(()=>{let a=[layer(1),layer(2,{outPoint:3})];run(87,{ls:a,answers:['0']});assert.equal(a[1].startTime,5)});
test(()=>{let a=[layer(1)];run(80,{ls:a,answers:['8']});assert.equal(a[0].text.expression,undefined)});
test(()=>{let a=[layer(1,{source:{width:1920,height:1080,pixelAspect:1}})];a[0].p['ADBE Rotate Z'].numKeys=1;run(22,{ls:a,answers:['fit']});assert.equal(a[0].p['ADBE Scale'].writes,0)});
console.log('PASS: 102 script syntax checks + panel syntax; exact IDs 1–102; '+n+' behavior scenarios. Adobe/macOS testing pending.');
