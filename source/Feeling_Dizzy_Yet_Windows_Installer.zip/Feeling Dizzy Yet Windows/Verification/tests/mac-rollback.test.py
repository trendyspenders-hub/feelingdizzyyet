from pathlib import Path
import tempfile,subprocess
prefix=Path(__file__).resolve().parents[1]/'mac-installer-prefix.sh'
s=prefix.read_text().split("<<'COPY'\n",1)[1].split('\nCOPY',1)[0]
# Linux simulation of filesystem operations, not execution on macOS.
s=s.replace('/usr/bin/ditto','/bin/cp -a')
for fail in [False,True]:
 with tempfile.TemporaryDirectory() as td:
  r=Path(td);src=r/'source';dest=r/'destination';src.mkdir();dest.mkdir()
  for p,label in [(src,'NEW'),(dest,'OLD')]:
   (p/'Feeling Dizzy Yet.jsx').write_text(label);(p/'FeelingDizzyYet').mkdir();(p/'FeelingDizzyYet/marker').write_text(label)
  code=s.replace('/bin/mv "$work/FeelingDizzyYet"','/bin/false "$work/FeelingDizzyYet"') if fail else s
  sh=r/'install.sh';sh.write_text(code)
  done=subprocess.run(['bash',str(sh),str(src),str(dest)],capture_output=True)
  assert (done.returncode!=0)==fail
  expected='OLD' if fail else 'NEW'
  assert (dest/'Feeling Dizzy Yet.jsx').read_text()==expected
  assert (dest/'FeelingDizzyYet/marker').read_text()==expected
  print('PASS Mac copy logic simulation: '+('failed swap restores previous pair' if fail else 'successful staged update'))
