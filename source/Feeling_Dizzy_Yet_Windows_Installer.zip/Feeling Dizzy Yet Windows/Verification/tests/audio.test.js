'use strict';const assert=require('assert'),fs=require('fs'),{analyzeWav,planCuts,toTSV,toXML,rate}=require('../shared/planner');
let passed=0;function test(name,fn){fn();passed++;console.log('PASS '+name);}
function env(duration,fn){const step=.05;return {duration,step,levels:Array.from({length:Math.ceil(duration/step)},(_,i)=>fn(i*step))};}
function wav(bits=16,code=1,channels=1,duration=.2){const sr=8000,n=Math.round(sr*duration),bytes=bits/8,b=new ArrayBuffer(44+n*channels*bytes),v=new DataView(b);const put=(p,s)=>[...s].forEach((c,i)=>v.setUint8(p+i,c.charCodeAt(0)));put(0,'RIFF');v.setUint32(4,b.byteLength-8,true);put(8,'WAVE');put(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,code,true);v.setUint16(22,channels,true);v.setUint32(24,sr,true);v.setUint32(28,sr*channels*bytes,true);v.setUint16(32,channels*bytes,true);v.setUint16(34,bits,true);put(36,'data');v.setUint32(40,n*channels*bytes,true);for(let i=0;i<n;i++)for(let ch=0;ch<channels;ch++){const a=.25*Math.sin(2*Math.PI*440*i/sr),p=44+(i*channels+ch)*bytes;if(code===3)v.setFloat32(p,a,true);else if(bits===16)v.setInt16(p,a*32767,true);else if(bits===32)v.setInt32(p,a*2147483647,true);else{let k=Math.round(a*8388607);v.setUint8(p,k&255);v.setUint8(p+1,(k>>8)&255);v.setUint8(p+2,(k>>16)&255);}}return b;}

const vm=require('vm'),ctx={};vm.runInNewContext(fs.readFileSync(__dirname+'/../AfterEffects/FeelingDizzyYet/multicam-core.jsxinc','utf8'),ctx);
function reader(b){const data=Buffer.from(b);let p=0;return {length:data.length,seek(x){p=x},read(n){const s=data.subarray(p,p+n).toString('latin1');p+=n;return s}}}
for(const [bits,code] of [[16,1],[24,1],[32,1],[32,3]])for(const ch of [1,2])test('AE streaming parity '+bits+'/'+code+'/'+ch,()=>{const b=wav(bits,code,ch),modern=analyzeWav(b),ae=ctx.FDYMulticam.analyzeReader(reader(b),.05);assert.equal(ae.duration,modern.duration);assert.equal(ae.levels.length,modern.levels.length);ae.levels.forEach((x,i)=>assert(Math.abs(x-modern.levels[i])<1e-9));});
test('AE cancellation',()=>assert.throws(()=>ctx.FDYMulticam.analyzeReader(reader(wav(16,1,1,2)),.05,()=>false),/cancel/));
test('AE malformed WAV',()=>assert.throws(()=>ctx.FDYMulticam.analyzeReader(reader(new ArrayBuffer(50)),.05)));
test('AE truncation',()=>assert.throws(()=>ctx.FDYMulticam.analyzeReader(reader(wav().slice(0,100)),.05)));
const envelope=t=>({duration:20,step:.05,levels:Array.from({length:400},(_,i)=>t(i*.05))}), aa=[envelope(t=>t<10?-15:-70),envelope(t=>t>=10?-15:-70)];
test('Same AE and Premiere cut plan',()=>assert.equal(JSON.stringify(ctx.FDYMulticam.planCuts(aa,{fps:30})),JSON.stringify(planCuts(aa,{fps:30}))));
test('NaN XML dimensions reject',()=>assert.throws(()=>toXML(planCuts(aa,{}),[{name:'A',path:'/a.mov'},{name:'B',path:'/b.mov'}],{width:NaN})));
console.log(passed+' integrated audio regression tests passed.');
