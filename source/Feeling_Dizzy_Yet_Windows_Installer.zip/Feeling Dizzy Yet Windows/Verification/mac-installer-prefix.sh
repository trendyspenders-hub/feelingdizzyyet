#!/bin/bash
# Feeling Dizzy Yet | Mac installer | 0.7.0
set -eo pipefail
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo 'This installer is for macOS. No changes were made.'
  exit 1
fi
umask 077
stage=$(mktemp -d "${TMPDIR:-/tmp}/feeling-dizzy-yet.XXXXXX")
trap 'rm -rf "$stage"' EXIT
printf '\nFEELING DIZZY YET\nAfter Effects automation studio — installer 0.7.0\n\n'
# The archive and expected hash are embedded when packaging.
payload_line=$(awk '/^__FDY_PAYLOAD_BELOW__$/ { print NR + 1; exit }' "$0")
if [[ -z "$payload_line" ]]; then echo 'Missing installer payload.'; exit 1; fi
tail -n +"$payload_line" "$0" | /usr/bin/base64 -D > "$stage/payload.tar.gz"
actual_hash=$(/usr/bin/shasum -a 256 "$stage/payload.tar.gz" | /usr/bin/awk '{print $1}')
if [[ "$actual_hash" != "8c463b1f6932d49adf3b4bc6ca32ec2808ee441fd5e3c732d06e8a11cf8da647" ]]; then echo 'Payload integrity check failed. Nothing installed.'; exit 1; fi
/usr/bin/tar -xzf "$stage/payload.tar.gz" -C "$stage"
versions=()
prefs="$HOME/Library/Preferences/Adobe/After Effects"
if [[ -d "$prefs" ]]; then
  for folder in "$prefs"/*; do
    [[ -d "$folder" ]] || continue
    version_name="${folder##*/}"
    if [[ "$version_name" =~ ^[0-9]+\.[0-9]+([.][0-9]+)?$ ]]; then versions+=("$version_name"); fi
  done
fi
choice=$(/usr/bin/osascript - "${versions[@]}" <<'APPLESCRIPT'
on run argv
  set choices to {}
  repeat with v in argv
    set end of choices to "After Effects " & (v as text) & " — install for this user"
  end repeat
  set end of choices to "Choose After Effects application folder…"
  set picked to choose from list choices with title "Feeling Dizzy Yet" with prompt "Choose where to install the panel. Close After Effects before continuing." default items {item 1 of choices} OK button name "Continue"
  if picked is false then return "CANCEL"
  return item 1 of picked
end run
APPLESCRIPT
) || { echo 'Installer cancelled.'; exit 0; }
if [[ "$choice" == 'CANCEL' ]]; then echo 'Installer cancelled.'; exit 0; fi
if [[ "$choice" == 'Choose After Effects application folder…' ]]; then
  app_folder=$(/usr/bin/osascript <<'APPLESCRIPT'
try
  set target to choose folder with prompt "Choose the Adobe After Effects folder that contains Scripts (usually in Applications)."
  return POSIX path of target
on error number -128
  return "CANCEL"
end try
APPLESCRIPT
)
  if [[ "$app_folder" == 'CANCEL' ]]; then exit 0; fi
  if [[ ! -d "$app_folder/Scripts" ]]; then
    /usr/bin/osascript -e 'display alert "Scripts folder not found" message "Choose the Adobe After Effects application folder containing a Scripts directory. Open After Effects once to enable the per-user option, then try again."'
    exit 1
  fi
  destination="${app_folder%/}/Scripts/ScriptUI Panels"
else
  chosen_version=""
  for v in "${versions[@]}"; do
    if [[ "$choice" == "After Effects $v — install for this user" ]]; then chosen_version="$v"; break; fi
  done
  if [[ -z "$chosen_version" ]]; then echo 'Invalid version selection.'; exit 1; fi
  destination="$prefs/$chosen_version/Scripts/ScriptUI Panels"
fi
/usr/bin/osascript - "$destination" "$stage/payload/FeelingDizzyYet/brand/FeelingDizzyYet.icns" <<'APPLESCRIPT'
on run argv
  display dialog "Install Feeling Dizzy Yet and its 102 scripts into:" & return & return & item 1 of argv & return & return & "Existing matching panel files will be backed up. This is an unsigned development preview for After Effects, with Adobe testing pending." with title "Feeling Dizzy Yet" buttons {"Cancel", "Install"} default button "Install" cancel button "Cancel" with icon (POSIX file (item 2 of argv))
end run
APPLESCRIPT
cat > "$stage/copy-panel.sh" <<'COPY'
#!/bin/bash
set -eo pipefail
src="$1"
dest="$2"
/bin/mkdir -p "$dest"
stamp="$(date +%Y%m%d-%H%M%S)-$$"
work="$dest/.fdy-stage-$stamp"
/bin/mkdir "$work"
oldpanel=0; olddata=0; newpanel=0; newdata=0
rollback() {
  code=$?
  trap - EXIT
  set +e
  if [[ "$code" -ne 0 ]]; then
    [[ "$newpanel" -eq 0 ]] || /bin/rm -f "$dest/Feeling Dizzy Yet.jsx"
    [[ "$newdata" -eq 0 ]] || /bin/rm -rf "$dest/FeelingDizzyYet"
    [[ "$oldpanel" -eq 0 ]] || /bin/mv "$dest/Feeling Dizzy Yet.jsx.backup-$stamp" "$dest/Feeling Dizzy Yet.jsx"
    [[ "$olddata" -eq 0 ]] || /bin/mv "$dest/FeelingDizzyYet.backup-$stamp" "$dest/FeelingDizzyYet"
    echo 'Installation failed; rollback attempted. Inspect destination and dated backups.' >&2
  fi
  /bin/rm -rf "$work"
  exit "$code"
}
trap rollback EXIT
/usr/bin/ditto "$src/Feeling Dizzy Yet.jsx" "$work/Feeling Dizzy Yet.jsx"
/usr/bin/ditto "$src/FeelingDizzyYet" "$work/FeelingDizzyYet"
if [[ -e "$dest/Feeling Dizzy Yet.jsx" ]]; then /bin/mv "$dest/Feeling Dizzy Yet.jsx" "$dest/Feeling Dizzy Yet.jsx.backup-$stamp"; oldpanel=1; fi
if [[ -e "$dest/FeelingDizzyYet" ]]; then /bin/mv "$dest/FeelingDizzyYet" "$dest/FeelingDizzyYet.backup-$stamp"; olddata=1; fi
/bin/mv "$work/Feeling Dizzy Yet.jsx" "$dest/Feeling Dizzy Yet.jsx"; newpanel=1
/bin/mv "$work/FeelingDizzyYet" "$dest/FeelingDizzyYet"; newdata=1
COPY
if [[ "$destination" == "$prefs/"* ]]; then
  /bin/bash "$stage/copy-panel.sh" "$stage/payload" "$destination"
else
  /usr/bin/osascript - "$stage/copy-panel.sh" "$stage/payload" "$destination" <<'APPLESCRIPT'
on run argv
  set cmd to "/bin/bash " & quoted form of item 1 of argv & " " & quoted form of item 2 of argv & " " & quoted form of item 3 of argv
  do shell script cmd with administrator privileges
end run
APPLESCRIPT
fi
printf '\nInstalled to: %s\nRestart After Effects, then choose Window > Feeling Dizzy Yet.\n' "$destination"
/usr/bin/osascript <<'APPLESCRIPT'
display dialog "Feeling Dizzy Yet is installed." & return & return & "Restart After Effects, then open Window → Feeling Dizzy Yet." with title "Feeling Dizzy Yet" buttons {"Done"} default button "Done"
APPLESCRIPT
exit 0
