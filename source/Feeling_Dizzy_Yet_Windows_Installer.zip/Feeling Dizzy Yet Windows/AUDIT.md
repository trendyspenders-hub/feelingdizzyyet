# Feeling Dizzy Yet - build audit
Audit date: 2026-10-23. Revised build: Premiere 0.2.0, AE panel 0.7.0.

## Verdict
Development preview. Source, audio logic, mocked adapters, package contents and shell syntax have been checked. **Not certified for production or sale.** No Premiere, After Effects, Windows or macOS runtime was available. Native installer execution, UI rendering, media import, audio routing, saved-project behavior and rendered results remain release gates. A declared minimum version is not forward-compatibility certification.

## Scope and baseline
Reviewed the existing Windows package, combined Mac/Premiere/AE package, and older AE-only Mac installer. Inspected AE utility source (100 original numbered files), the legacy TSV adapter, Premiere host adapter/catalog, multicam WAV/parser/planner/XML generator, manifests, documentation and both installer flows. The numbered collection contains related variants and two legacy launchers; it is not 100 independent AI editing engines. Revised AE collection has 102 entries; Premiere has 29 tools. The older AE-only Mac archive is superseded by the revised combined Mac download.

Baseline archive SHA-256:
- Windows: f81924ae176b1f516c5a8988fb1b10d3c32f16723576a50a0d4d44c3287c339d
- Combined Mac preview: 95752a985d40999d532b52ae45eeb9362c13edab108551228e949b36125e7b70
- Older Mac AE-only: 4140557578aa1deff13d7e3ee58b60ec7601e9e11ae3d3bdc8aa5b45e8b384a4

## Confirmed defects corrected
| Severity | Finding and trigger | Revision / evidence |
|---|---|---|
| High | AE 19 created 2-pixel solids below AE's 4-pixel minimum. | All guide solid dimensions at least 4; mocked minimum-size API accepts normal and tiny comps. |
| Medium | AE 65 accepted a 1-3 pixel progress bar, also invalid for solids. | Prompt now requires >=4; invalid height rejected before layer creation. |
| Medium | AE 36 allowed dense contact sheets whose height minus label allowance became negative. Camera audio also accumulated across cells. | Reject undersized cells before comp creation; mute cell audio. Dense-layout regression included. |
| Medium | AE 47 faded both overlapping layers, reducing combined alpha to 0.75 at midpoint. | Fade only incoming still; regression checks underlying opacity remains unkeyed. Visual Adobe render still required. |
| Medium | AE 22 accepted a currently zero rotation with animated rotation. | Require static rotation before changing fit transforms; regression verifies no scale writes. |
| Medium | XML dimensions could accept nonnumeric strings, producing invalid metadata; false-like values silently defaulted. | Explicit finite integer validation and undefined-only defaults; NaN rejection test. |
| Medium | Premiere prepare could finish after inputs changed, exposing an obsolete preview. | Disable input/navigation controls during asynchronous operations; multicam captures source/settings and rechecks active project, sequence and format. Mocked stale sequence/format tests pass. |
| High | AE panel installers moved existing files before copy without automatic rollback. | Stage full companion files first; restore dated backups after a failed swap. Mac shell rollback simulated on Linux; native OS behavior still pending. Windows VBS reviewed only. |
| Product | Multicam required a standalone HTML studio, then manual XML/TSV transfer. | Removed browser studio; Premiere controls live in UXP; AE uses native ScriptUI tool 102. Mocked full flows create new output and preserve the original. |

## Verification performed
- Syntax parsed for all 102 AE scripts and the panel; checked exact catalog IDs and file references.
- 21 selected existing AE utility mock scenarios, including animated-rotation rejection.
- 17 WAV/planner/XML tests: PCM16/24/32, float32, stereo, malformed/truncated WAVs, sustained change, interjection, overlap, silence, duration mismatch, contiguous frame ranges, escaping and absolute paths.
- 13 new audio regression checks: streaming/ArrayBuffer parity for all four encodings in mono and stereo, cancellation, malformed/truncated files, AE/Premiere cut-plan parity and NaN dimensions.
- 15 existing Premiere adapter mock scenarios for transaction construction, no mutation during preview, stale project/name rejection, markers and bounds.
- 4 Premiere multicam mock checks: select/load/analyze/review/internal import; stale sequence; changed dimensions; memory-size preflight.
- 2 native AE dialog mock checks: demo creates two timed cuts in a duplicate, with original camera audio/visibility unchanged; stale composition rejected.
- 5 audit regressions covering solid sizes, dense contact sheets and dissolve opacity.
- Total: **77 behavior checks**, plus syntax/catalog/package checks. These are simulated host checks, not Adobe end-to-end tests.
- Mac embedded payload hash and archive contents checked; shell files parsed. Windows VBS encoding and source paths checked. Package manifests regenerated after changes. ZIP integrity checked.

## Remaining risks and release gates
1. **High - Adobe execution:** install/load and run in Premiere 25.6 plus each newer supported release, and the intended AE releases, on both operating systems. Verify UXP DOM support, API object identity, async handling, native ScriptUI layout and permission prompts. Mock DOM tests cannot validate UXP rendering.
2. **High - Premiere import fidelity:** new first cuts are flattened editable segments created by internal Final Cut Pro XML import, not native switchable multicam. Check relinking, media duration, pixel aspect, timebases, channels, stereo pan and audio sync. It does not copy existing sequence grades/effects/graphics or honor source interpretation overrides/trim offsets. Require ordinary media pre-aligned to zero with matching output dimensions/rate.
3. **High - Packaging/signing:** Mac app/command is unsigned and not notarized; Windows is CMD/VBS, not MSI/EXE; Premiere is developer-load source, not signed CCX. Check Gatekeeper, file permissions, Windows Script Host/VBScript availability and managed-PC policies. No signature verification bypass is included.
4. **High - Install/update recovery:** real copy failure, permissions denial, locked files, update over prior versions, cancellation and uninstall/backup restore must be exercised on both systems. Backups are retained but restoration can itself fail. Windows hash manifest is for inspection; setup does not enforce it cryptographically. Mac self-extracting AE payload verifies its embedded SHA-256.
5. **Medium - Analysis accuracy:** level detection is not diarization or semantic understanding. Test real podcast bleed, gain differences, laughter, pauses, music and crosstalk. No automatic synchronization is provided. Review every cut.
6. **Medium - Performance:** synchronous RMS/planning can block UI; Premiere cancellation occurs between files. Enforced file/duration/shot bounds do not establish acceptable performance on all systems. Check one- and two-hour sessions and memory use.
7. **Medium - Complex AE comps:** expressions depending on layer indices, unusual blending, effects, disabled layers, text wrapping, mixed formatting, label overflow and short source footage require visual inspection. Scripts that fail during host mutation can leave partial work; undo groups are not database transactions. First-cut duplication keeps the original comp, but partial duplicates can remain.
8. **Medium - Utility coverage:** selected mock scenarios do not execute every branch of every utility. Layout variants, text variants, render-queue templates, expression reports and media imports all need representative project fixtures and rendered acceptance tests.
9. **Medium - Distribution quality:** establish installer signing, versioned releases, host compatibility matrix, support/rollback documentation and repeatable OS CI before paid distribution. Do not market this release as fully tested or universally compatible with future Adobe versions.

## Data and dependency review
Multicam runs locally and invokes no cloud model. No embedded API credentials were found in reviewed plugin/installer source. Local file paths appear in recovery files and reports. Existing source licenses remain included; this review is not a legal clearance of Adobe distribution terms. No external JavaScript dependency is needed by the shipped runtime. Test scripts require Node.js. Artwork/brand assets retain their included license notes.

## Acceptance record to collect
For each OS/host version: installer launch/update/uninstall; plugin load; tool 102 and Premiere multicam; 2/8 speakers plus optional wide; PCM formats; mismatched WAV duration; offline camera; cancellation; changed settings after analysis; first/last frame; stereo master; source unchanged; Undo; save/reopen; rendered sample. Record exact Adobe/OS versions, fixture, expected/actual result, error/line, screenshot or render evidence and recovery behavior.

## API references used
- https://developer.adobe.com/premiere-pro/uxp/plugins/
- https://developer.adobe.com/premiere-pro/uxp/ppro-reference/classes/project/
- https://developer.adobe.com/premiere-pro/uxp/ppro-reference/classes/clipprojectitem/
- https://developer.adobe.com/premiere-pro/uxp/ppro-reference/classes/sequence/
- https://ae-scripting.docsforadobe.dev/layer/layercollection/#layercollectionaddsolid
